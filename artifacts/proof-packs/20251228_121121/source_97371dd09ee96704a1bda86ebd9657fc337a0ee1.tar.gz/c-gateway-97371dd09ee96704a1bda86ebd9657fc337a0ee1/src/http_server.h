#ifndef HTTP_SERVER_H
#define HTTP_SERVER_H

#ifdef __cplusplus
extern "C" {
#endif

int http_server_run(const char *port);

#ifdef __cplusplus
}
#endif

#endif /* HTTP_SERVER_H */
