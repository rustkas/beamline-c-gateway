# Plan
1) Env contract
2) Parser/validator
3) Sanitization
4) Tests
5) Docs
