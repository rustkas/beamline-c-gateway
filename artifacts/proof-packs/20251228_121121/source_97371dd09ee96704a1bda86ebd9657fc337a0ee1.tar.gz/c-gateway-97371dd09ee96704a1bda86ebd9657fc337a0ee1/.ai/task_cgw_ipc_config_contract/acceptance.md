# Acceptance Criteria
1) Документированные env vars
2) Валидация
3) Sanitized snapshot

# Verification
См. plan.md для деталей
