# Goal (RU)
Единый env contract для IPC/bridge

# Goal (EN)
Unified env contract for IPC/bridge
