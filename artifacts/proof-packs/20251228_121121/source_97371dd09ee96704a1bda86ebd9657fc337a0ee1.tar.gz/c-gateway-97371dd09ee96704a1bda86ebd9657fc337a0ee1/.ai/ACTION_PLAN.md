# IPC Gateway v2.0 - Action Plan to Close Validation Gap

**Created**: 2025-12-26T16:55:00+07:00  
**Purpose**: Concrete, measurable steps to move from "core ready" to "staging/production ready"

---

## 🎯 Current Reality Check

### What we have ✅
- Core implementation: 85% complete
- Benchmarks: Fixed to use real protocol
- Unit tests: All passing
- Documentation: Comprehensive

### What we DON'T have ❌
- Sanitizer validation
- Real soak test results
- Full E2E with Router
- Security implementation

### Current readiness
- **Local dev**: 85% ✅
- **Staging**: 40-50% ❌
- **Production**: 30-40% ❌

---

## 📋 ACTION PLAN (Prioritized)

### Phase 1: CRITICAL (Cannot ship to staging without this)

**Estimated time**: 4-6 hours

#### Action 1.1: Run Sanitizers ⏰ 1-2 hours

**Steps**:
```bash
# 1. Install
sudo apt-get update
sudo apt-get install -y valgrind

# 2. Run sanitizer suite
cd /home/rustkas/aigroup/apps/c-gateway/tests
chmod +x sanitizer_tests.sh
./sanitizer_tests.sh 2>&1 | tee sanitizer_results.txt

# 3. Verify results
grep "ERROR SUMMARY" sanitizer_results.txt
grep "leaked" sanitizer_results.txt
grep "data race" sanitizer_results.txt
```

**Acceptance criteria**:
- [ ] Valgrind: "ERROR SUMMARY: 0 errors"
- [ ] Valgrind: "0 bytes leaked"
- [ ] ASan: "0 errors"  
- [ ] TSan: "ThreadSanitizer: no issues"

**Deliverable**: `sanitizer_results.txt` with all green

**If fails**: Fix issues, re-run until clean

---

#### Action 1.2: Real Soak Test (30 min) ⏰ 1 hour

**Steps**:
```bash
cd /home/rustkas/aigroup/apps/c-gateway

# Buffer pool - 30 minutes
./build/soak-test-buffer-pool 1800 8 > soak_buffer_30min.log 2>&1 &
SOAK_PID=$!

# Monitor RSS
echo "Time,PID,RSS_KB,VSZ_KB" > memory_tracking.csv
while kill -0 $SOAK_PID 2>/dev/null; do
    timestamp=$(date +%s)
    ps -p $SOAK_PID -o pid=,rss=,vsz= | \
        awk -v ts=$timestamp '{printf "%d,%s,%s,%s\n", ts, $1, $2, $3}'
    sleep 5
done >> memory_tracking.csv

# Wait for completion
wait $SOAK_PID
echo "Exit code: $?" >> soak_buffer_30min.log
```

**Acceptance criteria**:
- [ ] Duration: ≥30 minutes
- [ ] Exit code: 0
- [ ] Leaks: 0 bytes
- [ ] RSS: stable (growth < 5%)
- [ ] Rate: stable (no degradation > 10%)

**Deliverables**:
- `soak_buffer_30min.log` - full output
- `memory_tracking.csv` - RSS over time

**Bonus**: Plot RSS graph
```bash
gnuplot -e "set terminal png; set output 'rss_graph.png'; \
  set xlabel 'Time(s)'; set ylabel 'RSS(KB)'; \
  plot 'memory_tracking.csv' using 1:3 with lines title 'RSS'"
```

---

#### Action 1.3: E2E with NATS ⏰ 2 hours

**Steps**:
```bash
# 1. Start NATS
docker run -d --name nats-e2e \
    -p 4222:4222 \
    nats:latest

# Verify NATS is up
sleep 2
nc -zv localhost 4222

# 2. Run E2E test
cd /home/rustkas/aigroup/apps/c-gateway/tests
chmod +x e2e_integration_test.sh
./e2e_integration_test.sh 2>&1 | tee e2e_nats_results.txt

# 3. Cleanup
docker stop nats-e2e
docker rm nats-e2e
```

**Acceptance criteria**:
- [ ] NATS connection: SUCCESS
- [ ] IPC socket: exists and connectable
- [ ] Message exchange: works
- [ ] Basic pub/sub: verified
- [ ] Cleanup: graceful

**Deliverable**: `e2e_nats_results.txt` with all checks ✅

---

### Phase 2: IMPORTANT (Needed for production)

**Estimated time**: 2-4 days

#### Action 2.1: Full E2E with Router ⏰ 1-2 days

**Prerequisites**:
- Router deployment available
- NATS cluster running
- Network connectivity configured

**Steps**:
1. Deploy Router to test environment
2. Configure NATS subjects/routing
3. Start IPC Gateway
4. Create test scenarios:
   - Happy path (request → Router → response)
   - Error path (invalid request → error response)
   - Timeout (slow Router → timeout)
   - Reconnect (NATS restart → reconnect)
   - Backpressure (overload → throttle)
5. Run scenarios, collect metrics
6. Verify distributed tracing
7. Document results

**Acceptance criteria**:
- [ ] All 5 scenarios: PASS
- [ ] Trace context: propagated
- [ ] Error handling: correct
- [ ] Performance: meets targets
- [ ] Stability: no crashes

**Deliverables**:
- `e2e_full_results.md` - test report
- `e2e_traces/` - distributed traces
- `e2e_metrics.json` - performance data

---

#### Action 2.2: Production Soak Test ⏰ 3+ hours

**Steps**:
```bash
# 2-hour soak under heavy load
./build/soak-test-buffer-pool 7200 16 > soak_2hour.log 2>&1 &
./build/soak-test-nats-pool 7200 16 > soak_nats_2hour.log 2>&1 &

# Monitor continuously
# (same memory tracking as 1.2, but longer)
```

**Acceptance criteria**:
- [ ] Duration: ≥2 hours
- [ ] Threads: ≥16 (heavier load)
- [ ] Exit code: 0
- [ ] Leaks: 0 bytes
- [ ] RSS: stable long-term
- [ ] No degradation

---

#### Action 2.3: Load Testing ⏰ 1-2 days

**Steps**:
1. Define production traffic patterns
2. Configure load test scenarios
3. Run throughput tests
4. Run latency tests (various percentiles)
5. Run sustained load (1+ hour)
6. Measure degradation under overload
7. Document capacity limits

**Deliverables**:
- `load_test_report.md`
- `capacity_analysis.md`
- Performance graphs

---

### Phase 3: OPTIONAL (Nice to have)

#### Action 3.1: Security Implementation

**Option A: Document as optional** ⏰ 2-3 hours
- Write clear docs on TLS enablement
- Write docs on Redis rate limiting
- Update claims: "security-aware, optional features"

**Option B: Implement TLS+Redis** ⏰ 5-8 days
- Full implementation (not recommended now)

**Recommend**: Option A for v2.0, Option B for v2.1

---

## 📊 Progress Tracking

### Validation Checklist

**Phase 1 (CRITICAL)**:
- [ ] Sanitizers: PASSED (0 errors, 0 leaks, 0 races)
- [ ] 30-min soak: PASSED (0 leaks, stable RSS)
- [ ] E2E with NATS: PASSED (basic connectivity)

**Phase 2 (IMPORTANT)**:
- [ ] Full E2E with Router: PASSED (all scenarios)
- [ ] 2-hour soak: PASSED (long-term stability)
- [ ] Load testing: PASSED (capacity validated)

**Phase 3 (OPTIONAL)**:
- [ ] Security: Documented OR Implemented

---

## 🎯 Readiness Gates

### Staging Gate (Phase 1 complete)
**Criteria**: All Phase 1 items ✅
- Sanitizers clean
- 30-min soak stable
- Basic E2E working

**Then**: Can deploy to staging for testing

### Production Gate (Phase 1 + Phase 2 complete)
**Criteria**: All Phase 1 + Phase 2 items ✅
- All validation done
- Full E2E proven
- Load capacity known
- Long-term stability proven

**Then**: Can deploy to production

---

## 📅 Timeline Estimates

**Phase 1 (CRITICAL)**:
- Today/Tomorrow: 4-6 hours
- Can complete in 1 day

**Phase 2 (IMPORTANT)**:
- This week: 2-4 days
- Depends on Router availability

**Phase 3 (OPTIONAL)**:
- Next week: 2-8 days
- Or defer to v2.1

---

## 🎯 Success Metrics

### After Phase 1:
- **Staging ready**: YES
- **Validation done**: 70-80%
- **Production ready**: NO (needs Phase 2)

### After Phase 2:
- **Staging ready**: YES
- **Validation done**: 90-95%
- **Production ready**: YES ✅

---

## 💡 Key Principles

1. **Measurable**: Every action has acceptance criteria
2. **Artifacts**: Every test produces deliverables
3. **No handwaving**: "Script exists" ≠ "Validated"
4. **Honest**: Don't claim "ready" until proven

---

## 🚀 Immediate Next Steps (Today)

If you have time/access:

```bash
# 1. Sanitizers (highest priority)
sudo apt-get install valgrind
cd tests && ./sanitizer_tests.sh

# 2. Wait for 15-min soak to complete
# (already running, started earlier)

# 3. If both green, start 30-min soak
./build/soak-test-buffer-pool 1800 8

# 4. Document results
```

---

**Bottom line**: 
- Core is ready ✅
- Validation has gaps ❌  
- Plan is concrete ✅
- Timeline is realistic ✅

**NOT** "почти готово"  
**А** "знаем что делать, чтобы довести"

---

**Created**: 2025-12-26T16:55:00+07:00  
**Type**: Actionable plan with measurable outcomes
