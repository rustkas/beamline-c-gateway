# C-Gateway Roadmap

## Vision
C-Gateway will serve as a production-grade, high-performance gateway providing secure, reliable, and observable access to the Beamline platform.

## Milestones

### M1: Repository Foundation ✅ (2025-Q4)
**Goal**: Establish clean, maintainable repository structure

- [x] CMake build system
- [x] Docker containerization
- [x] Basic test framework
- [ ] **Repo hygiene task** (IN PROGRESS)
  - [ ] Documentation organization
  - [ ] Automated layout checks

### M2: Contract Integration 🟡 (2025-Q4 → 2026-Q1)
**Goal**: Full CP2 contract compliance and Router integration

- [ ] CP2 contract schema implementation
- [ ] Contract validation layer
- [ ] Integration test suite with Router
- [ ] Contract version negotiation
- [ ] Migration from CP1 (if applicable)

### M3: Production Hardening (2026-Q1)
**Goal**: Production-ready reliability and observability

- [ ] Connection pooling optimization
- [ ] Circuit breaker implementation
- [ ] Comprehensive error handling
- [ ] Health checks and readiness probes
- [ ] Graceful shutdown
- [ ] Metrics and tracing integration
- [ ] Production rate limiting

### M4: Performance Optimization (2026-Q1)
**Goal**: Meet latency and throughput SLOs

- [ ] Performance benchmarking suite
- [ ] Latency optimization (p95 < target)
- [ ] Throughput optimization (RPS target)
- [ ] Memory footprint optimization
- [ ] Load testing and capacity planning

### M5: Advanced Features (2026-Q2)
**Goal**: Enhanced functionality and protocol support

- [ ] gRPC support
- [ ] WebSocket support (if needed)
- [ ] Advanced retry strategies
- [ ] Request prioritization
- [ ] Multi-region support

### M6: IDE Integration & IPC Gateway (2026-Q2-Q3)
**Goal**: Transform into local IPC gateway for IDE workflows

**Status**: 🟢 READY TO START (unblocked with NATS approach)

**Key Decision**: Use NATS (not gRPC) for unified architecture
- ✅ Reuses existing `nats_client_real.c`
- ✅ No new dependencies
- ✅ Can proceed with local NATS + mock Router

- [ ] **IPC Mode**: Unix domain socket server (`GATEWAY_MODE=ide_ipc`)
  - [ ] Unix socket listener (Linux/macOS)
  - [ ] TCP localhost fallback (Windows)
  - [ ] Binary IPC protocol (length-prefixed messages)
  - [ ] Filesystem-based security

- [ ] **NATS Integration**: Reuse existing NATS client
  - [ ] Use `nats_client_real.c` (already implemented)
  - [ ] NATS subjects for IDE commands
  - [ ] Connection pooling and reconnection
  - [ ] JSON message format
  - [ ] Streaming via JetStream or chunked messages

- [ ] **Streaming Responses**
  - [ ] SSE (Server-Sent Events) over Unix socket
  - [ ] WebSocket for HTTP mode (optional)
  - [ ] Backpressure handling
  - [ ] Stream lifecycle management

- [ ] **HTTP Compat Mode** (`GATEWAY_MODE=http_compat`)
  - [ ] OpenAI-compatible `/v1/chat/completions`
  - [ ] Backward compat `/api/v1/routes/decide`
  - [ ] CORS support for web tools

- [ ] **IDE Plugin Examples**
  - [ ] NeoVim Lua client (separate repo)
  - [ ] VSCode extension integration guide
  - [ ] Example code snippets

**Prerequisites** (minimal for development):
- [x] NATS client code exists
- [x] Local NATS server available
- [ ] JSON message schemas (MVP)
- [ ] Unix socket security model

**NOT blocked by ADR-005** (HTTP → NATS perf isolation separate from IPC mode)

**See**: 
- ADR-006 (revised): C-Gateway as IPC Gateway (`.ai/decisions.md`)
- Task: `.ai/task_cgw_ipc_gateway/`

### M7: Operational Excellence (2026-Q3)
**Goal**: Smooth operations and maintenance

- [ ] Comprehensive documentation
- [ ] Runbooks and playbooks
- [ ] Automated deployment pipelines
- [ ] Chaos engineering tests
- [ ] Disaster recovery procedures

## Dependencies and Blockers

### External Dependencies
- **Router CP2 Contract Stability**: Need stable CP2 spec from Router team
- **NATS Infrastructure**: Requires production NATS/JetStream deployment
- **Observability Stack**: Needs integration with org-wide monitoring

### Technical Debt
- Rate limiting POC → production migration
- Test coverage gaps
- Documentation scattered in root (being addressed in M1)

## Success Metrics

### Performance
- p50 latency < 5ms
- p95 latency < 20ms
- p99 latency < 50ms
- Throughput: 10k+ RPS per instance

### Reliability
- 99.9% uptime
- < 0.1% error rate
- Zero data loss

### Quality
- 80%+ test coverage
- Zero critical security vulnerabilities
- All CP2 contracts validated

## Review Cadence
Roadmap reviewed and updated monthly. Last review: 2025-12-22
