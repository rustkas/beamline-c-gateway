# C-Gateway Project Overview

## Purpose
C-Gateway is a high-performance C/C++ service that acts as the gateway between external clients and the Beamline Router system. It provides:
- Request/response translation and validation
- NATS messaging integration
- Rate limiting and throttling
- Connection pooling and management

## Key Responsibilities
- Accept incoming HTTP/gRPC requests from external clients
- Validate and transform requests according to CP2 contracts
- Forward requests to Beamline Router via NATS request-reply
- Handle responses and errors from Router
- Implement client-facing API contracts

## Technology Stack
- **Language**: C/C++
- **Build System**: CMake
- **Messaging**: NATS (using C NATS client library)
- **Testing**: Google Test framework
- **Container**: Docker

## Related Systems
- **Beamline Router**: Primary backend service (Erlang/OTP)
- **NATS**: Message broker for inter-service communication
- **Monitoring**: Integration with observability stack

## Repository Structure
- `src/`: Core application source code
- `include/`: Public header files
- `tests/`: Unit and integration tests
- `config/`: Configuration files
- `scripts/`: Build, test, and maintenance scripts
- `docs/`: Technical documentation
