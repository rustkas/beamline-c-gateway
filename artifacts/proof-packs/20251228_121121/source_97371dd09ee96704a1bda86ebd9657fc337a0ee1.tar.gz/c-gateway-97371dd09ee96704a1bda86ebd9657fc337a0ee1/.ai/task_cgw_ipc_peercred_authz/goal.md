# Goal (RU)
SO_PEERCRED авторизация

# Goal (EN)
SO_PEERCRED authorization
