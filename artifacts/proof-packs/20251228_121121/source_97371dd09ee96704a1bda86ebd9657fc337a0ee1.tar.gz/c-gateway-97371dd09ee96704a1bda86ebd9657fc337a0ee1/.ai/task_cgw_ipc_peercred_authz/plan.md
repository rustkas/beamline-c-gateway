# Plan
1) Extract SO_PEERCRED
2) Allowlist
3) Docs
4) Tests
