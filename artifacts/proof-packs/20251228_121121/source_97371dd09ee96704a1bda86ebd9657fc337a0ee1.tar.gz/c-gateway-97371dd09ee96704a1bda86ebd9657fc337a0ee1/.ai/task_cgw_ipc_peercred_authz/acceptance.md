# Acceptance Criteria
1) SO_PEERCRED check
2) Allowlist
3) Docs

# Verification
См. plan.md для деталей
