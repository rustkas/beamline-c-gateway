# Goal (RU)
Фильтрация PII/секретов в логах

# Goal (EN)
PII/secret filtering in logs
