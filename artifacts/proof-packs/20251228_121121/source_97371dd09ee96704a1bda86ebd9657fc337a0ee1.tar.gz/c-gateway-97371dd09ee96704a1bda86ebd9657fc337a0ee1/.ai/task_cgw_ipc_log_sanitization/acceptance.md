# Acceptance Criteria
1) No raw secrets
2) Recursive masking
3) Tests

# Verification
См. plan.md для деталей
