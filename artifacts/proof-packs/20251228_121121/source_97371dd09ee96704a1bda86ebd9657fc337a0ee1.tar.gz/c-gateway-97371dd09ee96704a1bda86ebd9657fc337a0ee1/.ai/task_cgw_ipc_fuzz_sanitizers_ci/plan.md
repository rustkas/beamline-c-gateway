# Plan
1) Fuzz harness
2) Sanitizer flags
3) CI integration
