# Acceptance Criteria
1) Fuzz test
2) Sanitizer build
3) Docs

# Verification
См. plan.md для деталей
