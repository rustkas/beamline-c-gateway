# Acceptance Criteria
1) Единые таргеты
2) CI тесты
3) Демо из build output

# Verification
См. plan.md для деталей
