# Goal (RU)
Интегрировать IPC Gateway в основной build

# Goal (EN)
Integrate IPC Gateway into main build
