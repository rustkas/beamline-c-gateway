# Plan
1) Определить build систему
2) Подключить IPC
3) Add targets
4) Tests
5) Docs
