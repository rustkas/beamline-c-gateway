# Plan
1) Message types
2) Server delivery
3) Mock Router
4) Tests
