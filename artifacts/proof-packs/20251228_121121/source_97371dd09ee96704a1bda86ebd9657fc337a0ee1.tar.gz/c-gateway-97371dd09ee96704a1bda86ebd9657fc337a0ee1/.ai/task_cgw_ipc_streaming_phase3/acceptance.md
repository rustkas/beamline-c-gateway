# Acceptance Criteria
1) Stream lifecycle
2) N chunks
3) Error handling
4) E2E test

# Verification
См. plan.md для деталей
