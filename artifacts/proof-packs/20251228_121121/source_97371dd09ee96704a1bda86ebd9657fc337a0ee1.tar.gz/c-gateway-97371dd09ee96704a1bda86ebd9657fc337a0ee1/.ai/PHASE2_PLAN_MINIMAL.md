# Phase 2 Plan - Minimal (Production Gate)

**Date**: 2025-12-26T21:10:00+07:00  
**Status**: After Phase 1 completion  
**Focus**: Router E2E + Long Soak

---

## P0: Router E2E in Staging

### Prerequisites
- Staging environment with Router deployed
- NATS cluster accessible
- IPC Gateway deployed to staging

---

### Scenario 1: Happy Path (N=1000)

**Purpose**: Validate basic request-reply flow

**Test**:
```bash
# Send 1000 requests through full stack
# IPC → Gateway → NATS → Router → NATS → Gateway → IPC

for i in {1..1000}; do
  echo '{"task_id":"'$i'","payload":"test"}' | \
    nc -U /tmp/beamline-gateway.sock
done
```

**Success criteria**:
- [ ] 1000/1000 responses received
- [ ] Correct envelope format
- [ ] Trace context propagated
- [ ] Response time < 100ms (p99)

**Artifacts**:
- `artifacts/e2e/happy_path_results.log`
- Latency distribution CSV

---

### Scenario 2: Router Slow → Timeout

**Purpose**: Catch "late reply" memory/stats bugs

**Test**:
```bash
# Configure Router with artificial delay (e.g., 6s)
# Gateway timeout: 5s

# Send requests, expect timeouts
# Then verify late replies don't corrupt state
```

**Success criteria**:
- [ ] Gateway times out correctly (5s)
- [ ] Late replies (6s) don't crash gateway
- [ ] No memory leaks from orphaned replies
- [ ] Statistics accurate (timeouts counted)

**Artifacts**:
- `artifacts/e2e/timeout_test_results.log`
- Memory dump before/after

---

### Scenario 3: Router Errors

**Purpose**: Validate error envelope → IPC error code translation

**Test**:
```bash
# Send requests that trigger Router errors:
# - Invalid subject
# - Missing required fields
# - Business logic errors (400)
# - Internal errors (500)
```

**Success criteria**:
- [ ] Router error codes translated correctly
- [ ] Error messages preserved
- [ ] Gateway doesn't crash on errors
- [ ] Proper IPC error responses

**Artifacts**:
- `artifacts/e2e/error_handling_results.log`
- Error code mapping validation

---

### Scenario 4: NATS Reconnect Storm

**Purpose**: Verify pool doesn't degrade under reconnects

**Test**:
```bash
# During load test:
# 1. Kill NATS connection
# 2. NATS reconnects
# 3. Repeat 10x while sending requests

# Monitor: connection pool health, request success rate
```

**Success criteria**:
- [ ] Pool reconnects successfully all 10x
- [ ] Request success rate > 95% (allowing brief degradation)
- [ ] No connection leaks
- [ ] Pool size stable after reconnects

**Artifacts**:
- `artifacts/e2e/reconnect_storm_results.log`
- Pool stats over time CSV

---

## P0 Summary

**Execution**:
- Location: Staging environment
- Duration: 2-4 hours total
- Automation: Scripts for each scenario

**Deliverables**:
- 4 test result files
- Summary report
- All artifacts in `artifacts/e2e/`

**Acceptance**: All 4 scenarios PASS

---

## P1: Nightly Long Soak

### Test Configuration

```bash
# Run nightly (automated)
scripts/soak_with_metrics.sh 7200 8  # 2 hours, 8 threads
```

**Monitoring**:
- RSS every 5 seconds
- FD count every 5 seconds
- Throughput every 30 seconds

**Acceptance criteria**:
- [ ] Exit code: 0
- [ ] RSS growth: < 5%
- [ ] FD stable (no growth)
- [ ] Throughput stable (< 5% degradation)
- [ ] 0 memory leaks

**Artifacts**:
- `artifacts/soak-nightly/<date>/metrics.csv`
- `artifacts/soak-nightly/<date>/analysis.txt`
- `artifacts/soak-nightly/<date>/SUMMARY.md`

**Schedule**: 
- Run nightly in staging
- Not required for initial staging deployment
- Required for production gate

---

## Timeline

### Week 1 (Staging Deployment)
1. Deploy to staging
2. Run P0 Router E2E (all 4 scenarios)
3. Fix issues if any
4. **Gate**: P0 complete → 90% production ready

### Week 2 (Production Prep)
1. Nightly soak tests (P1)
2. Analyze long-term stability
3. Fix issues if any
4. **Gate**: P1 complete → 95% production ready

### Production Deployment
- After both P0 and P1 pass
- Gradual rollout
- Monitor closely

---

## Acceptance Gates

### Staging Deployment ✅
- Phase 1: Complete (80-85%)
- Can deploy to staging NOW

### Production Gate 🚧
**Required**:
- [ ] P0: Router E2E (4/4 scenarios PASS)
- [ ] P1: 2-hour soak (stable, 0 leaks)

**Optional enhancements**:
- [ ] Load testing
- [ ] Security audit
- [ ] TLS implementation

**Then**: Production-ready (90-95%)

---

## Scripts to Create

### For P0 (Router E2E):

```bash
tests/e2e_router_happy_path.sh       # Scenario 1
tests/e2e_router_timeout.sh          # Scenario 2
tests/e2e_router_errors.sh           # Scenario 3  
tests/e2e_router_reconnect_storm.sh  # Scenario 4
tests/run_all_e2e.sh                 # Runner
```

### For P1 (Nightly Soak):

```bash
scripts/soak_with_metrics.sh         # Already created ✅
scripts/schedule_nightly_soak.sh     # Cron setup
```

---

## Estimated Effort

**P0 (Router E2E)**:
- Script creation: 1-2 days
- Execution: 2-4 hours
- Analysis: 2-4 hours
- **Total**: 2-3 days

**P1 (Nightly Soak)**:
- Script: Already done ✅
- Setup cron: 1 hour
- Per run: 2 hours (automated)
- Analysis: 1 hour per run
- **Total**: Ongoing (nightly)

---

## Minimal Checklist

**Before Production**:
- [ ] Phase 1: Complete ✅
- [ ] Deploy to staging ✅
- [ ] P0: Router E2E (4 scenarios) 🚧
- [ ] P1: 2h soak (nightly) 🚧
- [ ] Review all artifacts
- [ ] → Production deployment

**No extras needed** - this is minimal gate

---

**Next Action**: Deploy to staging, then execute P0
