# Goal (RU)
Ops/release compliance

# Goal (EN)
Ops/release compliance
