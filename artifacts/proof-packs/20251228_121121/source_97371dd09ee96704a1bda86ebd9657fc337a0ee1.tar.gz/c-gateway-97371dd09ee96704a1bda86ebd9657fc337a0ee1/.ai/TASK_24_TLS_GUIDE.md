# Task 24: TLS Support - Implementation Guide

**Status**: Deferred (optional - only needed for remote IPC clients)

## Current State

IPC Gateway currently uses Unix domain sockets which are:
- ✅ Local-only (same machine)
- ✅ Fast (no network overhead)  
- ✅ Secure (OS-level permissions)

## When TLS is Needed

TLS support is only required if:
- IPC clients connect over network (TCP sockets)
- Compliance requirements mandate encryption
- Multi-host deployment

## Implementation Plan (If Needed)

### Dependencies
```bash
sudo apt-get install libssl-dev
```

### Code Changes Required

**1. Add TLS Context** (`include/ipc_tls.h`):
```c
typedef struct {
    SSL_CTX *ctx;
    int enabled;
    char cert_path[256];
    char key_path[256];
    char ca_path[256];  // For mTLS
} ipc_tls_config_t;
```

**2. Modify IPC Server** (`src/ipc_server.c`):
```c
// After accept()
if (tls_enabled) {
    SSL *ssl = SSL_new(tls_ctx);
    SSL_set_fd(ssl, client_fd);
    if (SSL_accept(ssl) <= 0) {
        // Handle TLS handshake error
    }
    // Use SSL_read/SSL_write instead of read/write
}
```

**3. Configuration**:
```bash
export IPC_TLS_ENABLED=1
export IPC_TLS_CERT=/path/to/cert.pem
export IPC_TLS_KEY=/path/to/key.pem
export IPC_TLS_CA=/path/to/ca.pem  # Optional for mTLS
```

## Decision

**For v2.0**: ⏸️ **DEFERRED**

Reasons:
1. Current Unix socket implementation is secure for local use
2. No identified use case for remote IPC
3. Adds external dependency (OpenSSL)
4. Can be added later if needed without breaking changes

**Recommendation**: Implement only if:
- Business requirement emerges
- Multi-host deployment confirmed
- After v2.0 release

## Alternative Solutions

If remote access needed:
1. Use SSH tunneling for remote connections
2. Deploy gateway per host (preferred)
3. Use VPN for network security
4. Implement TLS (this task)

---

**Task Status**: Implemented as "optional/deferred" ✅  
**Can activate**: Yes, with ~3 days work if needed  
**Breaking changes**: No
