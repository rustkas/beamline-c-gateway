# P0 Actions for Staging Readiness

**Date**: 2025-12-26T20:50:00+07:00  
**Priority**: P0 - Must complete before staging deployment

---

## P0-1: Clean Up Benchmark Artifacts

### Problem
- Multiple benchmark implementations (old vs new)
- Inconsistent socket paths across scripts
- Risk of running wrong benchmarks

### Actions
- [ ] Identify all benchmark files
- [ ] Remove/archive old benchmarks
- [ ] Standardize socket path contract
- [ ] Update all scripts to use canonical path
- [ ] Document benchmark usage

**Estimated time**: 30-45 minutes

---

## P0-2: Run & Archive Sanitizer Results

### Problem
- Sanitizers run but results not archived
- No "facts only" artifacts for review
- Missing TSAN validation

### Actions
- [ ] Run ASAN on all components
- [ ] Run UBSAN on all components
- [ ] Run TSAN on all components
- [ ] Run Valgrind on all components
- [ ] Save all results to `artifacts/sanitizers/`
- [ ] Create summary report

**Estimated time**: 1-2 hours

---

## P0-3: Proper Soak Test with Metrics

### Problem
- 30-min soak done but no RSS/FD monitoring
- No periodic samples saved
- Missing resource usage graphs

### Actions
- [ ] Run 30-min soak with monitoring
- [ ] Capture RSS every 5 seconds
- [ ] Capture FD count every 5 seconds
- [ ] Save metrics to CSV
- [ ] Generate graphs (optional)
- [ ] Document results

**Estimated time**: 45 minutes (30 min test + 15 min setup)

---

## P0-4: Full E2E with Router

### Problem
- Current E2E is mock/basic
- Not testing real Router semantics
- Missing error handling validation

### Actions
- [ ] Create E2E test plan
- [ ] Set up Router environment
- [ ] Test: Happy path (submit → response)
- [ ] Test: Error scenarios (400/500)
- [ ] Test: Timeout handling
- [ ] Test: Reconnect/resubscribe
- [ ] Test: Backpressure
- [ ] Document results

**Estimated time**: 4-8 hours (requires Router deployment)

---

## Execution Order

### TODAY (if possible):
1. **P0-1**: Benchmark cleanup (30-45 min)
2. **P0-2**: Sanitizers + artifacts (1-2 hours)
3. **P0-3**: Soak with metrics (45 min)

**Total: 3-4 hours**

### STAGING:
4. **P0-4**: Full E2E with Router (do in staging environment)

---

## Acceptance Criteria

### P0-1: Benchmarks
- ✅ Only canonical benchmarks in repo
- ✅ One socket path definition
- ✅ All scripts use same path
- ✅ Old benchmarks removed/archived

### P0-2: Sanitizers
- ✅ All sanitizer results saved to `artifacts/`
- ✅ Summary report created
- ✅ 0 errors, 0 leaks proven
- ✅ "Facts only" - no interpretation

### P0-3: Soak
- ✅ 30-min test with monitoring
- ✅ RSS/FD captured every 5s
- ✅ CSV file with metrics
- ✅ Results documented

### P0-4: E2E
- ✅ All 7 scenarios tested
- ✅ Real Router used
- ✅ Results documented
- ✅ Error handling validated

---

## Start: P0-1 Benchmark Cleanup
