# Evidence Pack - Phase 1 Validation (FACTS ONLY)

**Date**: 2025-12-26T21:00:00+07:00  
**Type**: Evidence-based validation report  
**Commit**: (not tracked - not a git repo)

---

## DISCLAIMER

This is a **facts-only** report. Claims like "production-grade" or "perfect cleanup" require artifacts. Below are the actual commands run, parameters used, and evidence collected.

---

## 1. AddressSanitizer (ASan)

### Build Commands

```bash
cd build
cmake .. -DCMAKE_C_FLAGS="-g -fsanitize=address -fno-omit-frame-pointer" \
         -DCMAKE_EXE_LINKER_FLAGS="-fsanitize=address"
make test-buffer-pool test-nats-pool test-trace-context
```

### Execution Commands

```bash
ASAN_OPTIONS=detect_leaks=1:halt_on_error=0 ./test-buffer-pool
ASAN_OPTIONS=detect_leaks=1:halt_on_error=0 ./test-nats-pool
ASAN_OPTIONS=detect_leaks=1:halt_on_error=0 ./test-trace-context
```

### ASan Options Used
- `detect_leaks=1` - Enable leak detection
- `halt_on_error=0` - Continue after errors (to collect all)

**NOTE**: Did **NOT** use `halt_on_error=1` (stricter)

### Results
- All tests: Passed
- Errors detected: 0
- Leaks detected: 0

### Evidence
- Logs: `/tmp/asan_*.log` (from earlier runs)
- Artifacts: `artifacts/sanitizers/20251226_205139/asan_*.log`

**Limitation**: ASan options were not maximally strict

---

## 2. Valgrind

### Toolchain
- Valgrind version: 3.18.1
- GCC version: (see below for actual version)

### Build Commands

```bash
cd build
cmake .. -DCMAKE_C_FLAGS="-g -gdwarf-4" -DCMAKE_EXE_LINKER_FLAGS=""
make test-buffer-pool test-nats-pool test-trace-context test-circuit-breaker
```

### Execution Commands

```bash
valgrind --leak-check=full \
         --show-leak-kinds=all \
         --track-origins=yes \
         --error-exitcode=1 \
         ./test-buffer-pool

# Repeated for: test-nats-pool, test-trace-context, test-circuit-breaker
```

### Valgrind Options Used
- `--leak-check=full` ✅
- `--show-leak-kinds=all` ✅
- `--track-origins=yes` ✅
- `--error-exitcode=1` ✅

**NOTE**: Did **NOT** use `--errors-for-leak-kinds=all` (was not specified)

### Results (example: test-buffer-pool)

```
HEAP SUMMARY:
  in use at exit: 0 bytes in 0 blocks
  total heap usage: 45 allocs, 45 frees, 26,088 bytes allocated

All heap blocks were freed -- no leaks are possible

ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

### Evidence
- Full logs: `artifacts/sanitizers/20251226_205139/valgrind_*.log`
- Summary: `artifacts/sanitizers/20251226_205139/valgrind_summary.txt`

**Proven**: 0 leaks on 4 components with valgrind

---

## 3. Soak Test (30 minutes)

### Execution Command

```bash
./build/soak-test-buffer-pool 1800 8
```

### Parameters
- Duration: 1800 seconds (30 minutes)
- Threads: 8
- Pool size: 32 buffers (hardcoded in test)

### Results

```
Duration:           1800 seconds
Total Acquired:     24,224,348
Total Released:     24,224,348
Errors:             0
Pool Stats:
  Total buffers:    32
  Available:        32
Rate:               13,458 ops/sec
Exit Code:          0
```

### Performance Stability

```
[300s]  Rate: 13,367 ops/sec
[900s]  Rate: 13,387 ops/sec
[1800s] Rate: 13,458 ops/sec
Variance: < 1%
```

### Evidence
- Full log: `/tmp/soak_buffer_30min.log`
- Results shown in validation reports

**Limitation**: 
- **NO RSS/FD monitoring** (was not captured)
- **NO periodic samples saved**
- Only final output captured

**What's NOT proven**:
- Long-term resource growth (need hourly soak)
- Memory fragmentation
- Real-world payload distribution

---

## 4. E2E with NATS

### NATS Setup

**Local server** (not Docker):
```bash
nats-server -p 4222 -a 127.0.0.1
```

- NATS version: (not captured)
- Configuration: Default

### Tests Executed

```bash
cd build
./test-nats-pool  # 6 tests
./test-buffer-pool  # 5 tests
./test-trace-context  # 5 tests
./test-circuit-breaker  # 5 tests
```

### What Was Tested
- NATS connectivity (port 4222)
- Connection pool acquire/release
- Concurrent access (50 operations)
- Health checks
- Pool exhaustion

### Results
- Total tests: 21/21 passed
- NATS pool tests: 6/6 passed

### Evidence
- Test outputs in validation reports
- NATS server was running (verified with `nc -zv localhost 4222`)

**What's NOT tested**:
- ❌ Real Router subjects/headers
- ❌ Error scenarios from Router
- ❌ Timeout/late reply handling
- ❌ Reconnect/resubscribe logic
- ❌ Backpressure under Router degradation
- ❌ Envelope ↔ Router contract

---

## 5. System Information

### Build Environment

```bash
GCC: (version not captured - need to run gcc --version)
CMake: (version not captured)
OS: Linux (Ubuntu-based, exact version not captured)
```

**Missing**:
- Exact compiler version
- CMake version
- Kernel version
- CPU/memory specs

---

## HONEST ASSESSMENT

### What's PROVEN (with evidence):

1. **Memory Safety - Basic** ✅
   - ASan: 0 errors, 0 leaks (with caveats on options)
   - Valgrind: 0 leaks on 4 components
   - Evidence: Logs in `artifacts/sanitizers/`

2. **30-min Stability** ✅
   - 24M operations completed
   - 0 leaks detected
   - Stable throughput (< 1% variance)
   - Evidence: Test output (no RSS/FD monitoring)

3. **NATS Connectivity** ✅
   - Basic integration works
   - Connection pooling functional
   - Evidence: Test outputs

### What's CLAIMED but NOT fully proven:

1. **"Production-grade"** ❌
   - Claim: Too strong
   - Reality: Staging-grade proven
   - Missing: Hours-long soak, real load patterns

2. **"Perfect cleanup"** ❌
   - Claim: Too strong
   - Reality: 0 leaks in controlled tests
   - Missing: RSS/FD monitoring over time

3. **"E2E complete"** ❌
   - Claim: Misleading
   - Reality: Basic NATS connectivity only
   - Missing: Full Router integration

### What's MISSING for Production:

1. **E2E with Router** ❌
   - No real Router testing
   - No subject/header validation
   - No error scenario testing
   - **This is the biggest risk**

2. **Long Soak** ❌
   - Only 30-min (staging-grade)
   - Need: 1-2 hours minimum for production
   - Need: RSS/FD monitoring

3. **Load Testing** ❌
   - No burstiness testing
   - No payload distribution
   - No reconnect storms
   - No production-like patterns

4. **Security** ❌
   - TLS: Not implemented
   - Rate limiting: Not integrated
   - PII policy: Not defined

---

## HONEST STATUS

### Staging Ready: **80-85%** ✅

**Evidence supports**:
- Memory safe for basic scenarios
- Stable for 30 minutes
- NATS integration works
- Components tested

**Good enough for** staging deployment

### Production Ready: **40-50%** ❌

**Missing critical evidence**:
- No Router E2E
- No long-term soak
- No load testing
- No security implementation

**NOT ready for** production deployment

---

## Evidence Gaps to Fill

### For 90% Staging Ready:
1. Capture system info (gcc/cmake/kernel versions)
2. Run soak with RSS/FD monitoring
3. Save full command history

### For Production (90%+):
1. **Full Router E2E** (biggest gap)
2. 1-2 hour soak with monitoring
3. Load test with real patterns
4. Security implementation OR documented waiver

---

## Artifacts Location

**Saved**:
- `artifacts/sanitizers/20251226_205139/*.log`
- Validation reports in `.ai/`

**Missing** (should have):
- Full command history
- System specs
- Git commit hash
- Exact tool versions
- RSS/FD monitoring data

---

**Bottom Line**: 

**Proven**: Staging-ready (80-85%) with evidence  
**NOT Proven**: Production-ready  
**Biggest Gap**: Router E2E testing

**Claims downgraded to match evidence.**
