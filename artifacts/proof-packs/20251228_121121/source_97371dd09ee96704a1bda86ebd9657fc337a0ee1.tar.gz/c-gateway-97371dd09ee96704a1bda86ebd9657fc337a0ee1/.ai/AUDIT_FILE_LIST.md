# Minimum Files List for Code Audit

Если хотите проверить "исправлено / не исправлено" по коду:

## Benchmarks (P0 fixes)

1. `benchmarks/bench_ipc_throughput.c` ✅ Provided above
2. `benchmarks/bench_ipc_latency.c` ✅ Provided above  
3. `benchmarks/run_benchmarks.sh` ✅ Provided above

**Ключевые моменты для проверки**:
- Line 8: `#include "ipc_protocol.h"` - использует реальный протокол
- Lines 39-73: `send_all()` / `recv_all()` - корректный I/O
- Line 89: `ipc_encode_message()` - реальное кодирование
- Lines 138-140: `SO_RCVTIMEO/SNDTIMEO` - таймауты
- Line 23: `#define WARMUP_REQUESTS 100` - warmup  
- Line 32: Socket existence check - `if [ ! -S "$IPC_SOCKET_PATH" ]`

## Soak Tests

4. `tests/soak_test_buffer_pool.c`
5. `tests/soak_test_nats_pool.c`

**Но**: Ran only 10s (smoke), NOT real soak

## Sanitizers

6. `tests/sanitizer_tests.sh`

**Но**: Script exists, NOT executed

## E2E

7. `tests/e2e_integration_test.sh`

**Но**: Mock check, NO real Router

---

## Summary for Audit

**Code fixes**: ✅ VERIFIED (benchmarks use real protocol)  
**Validation**: ❌ NOT DONE (no sanitizers, no real soak, no E2E)

**Honest assessment**: 
- Core implementation: 85%
- Validation: 30-40%
- Production readiness: 40-50%

---

**NOT "deploy now"**, but **"good progress, needs validation"**
