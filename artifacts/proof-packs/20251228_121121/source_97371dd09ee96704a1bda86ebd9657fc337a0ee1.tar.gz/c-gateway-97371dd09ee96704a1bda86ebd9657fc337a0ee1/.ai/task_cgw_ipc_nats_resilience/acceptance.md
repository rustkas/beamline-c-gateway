# Acceptance Criteria
1) No hang on NATS down
2) Reconnect backoff
3) Inflight limits
4) E2E test

# Verification
См. plan.md для деталей
