# Goal (RU)
NATS resilience: reconnect/backoff

# Goal (EN)
NATS resilience: reconnect/backoff
