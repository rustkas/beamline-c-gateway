# Goal (RU)
Backpressure: inflight лимиты

# Goal (EN)
Backpressure: inflight limits
