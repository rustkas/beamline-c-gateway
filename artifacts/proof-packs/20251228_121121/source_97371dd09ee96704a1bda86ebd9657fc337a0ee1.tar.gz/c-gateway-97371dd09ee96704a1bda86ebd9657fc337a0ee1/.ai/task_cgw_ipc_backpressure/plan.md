# Plan
1) Inflight counters
2) Rejection logic
3) Burst test
