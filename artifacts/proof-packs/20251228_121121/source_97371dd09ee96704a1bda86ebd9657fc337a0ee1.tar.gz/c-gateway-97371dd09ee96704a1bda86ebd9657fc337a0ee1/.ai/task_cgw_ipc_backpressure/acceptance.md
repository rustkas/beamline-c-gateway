# Acceptance Criteria
1) Per-conn/global limits
2) BUSY rejection
3) Burst test

# Verification
См. plan.md для деталей
