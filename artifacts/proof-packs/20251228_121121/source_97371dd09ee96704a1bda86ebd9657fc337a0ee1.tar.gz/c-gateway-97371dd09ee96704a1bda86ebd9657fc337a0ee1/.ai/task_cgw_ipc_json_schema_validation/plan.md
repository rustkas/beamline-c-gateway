# Plan
1) Schemas
2) Validator
3) Integration
4) Tests
