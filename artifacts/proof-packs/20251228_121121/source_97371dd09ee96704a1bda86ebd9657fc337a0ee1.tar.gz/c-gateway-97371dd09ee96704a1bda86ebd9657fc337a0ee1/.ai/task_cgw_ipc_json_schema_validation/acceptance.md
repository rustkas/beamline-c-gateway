# Acceptance Criteria
1) Schema files
2) Validation errors
3) Tests

# Verification
См. plan.md для деталей
