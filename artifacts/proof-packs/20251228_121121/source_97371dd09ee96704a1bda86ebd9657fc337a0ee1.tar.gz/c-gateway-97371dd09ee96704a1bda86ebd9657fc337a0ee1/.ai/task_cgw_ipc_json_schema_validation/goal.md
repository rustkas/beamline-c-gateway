# Goal (RU)
JSON Schema валидация

# Goal (EN)
JSON Schema validation
