# Implementation Plan: Repo Documentation Hygiene

## Approach
Implement in phases to ensure safety and idempotence:
1. Create scripts first (with dry-run capability)
2. Test scripts on current state
3. Execute migration
4. Validate results

## Phases

### Phase 1: Prepare Target Directories (5 min)
**Goal**: Ensure target directories exist

```bash
mkdir -p docs/plans
mkdir -p docs/poc
mkdir -p docs/backlog
```

**Output**: Three directories created

### Phase 2: Create Tidy Script (15 min)
**Goal**: Create idempotent migration script

**File**: `scripts/tidy_markdown.sh`

**Logic**:
```bash
#!/usr/bin/env bash
set -euo pipefail

# Define whitelist (files allowed in root)
WHITELIST=("README.md" "LICENSE.md" "LICENCE.md")

# Define mapping: source file → target directory
declare -A MOVE_MAP=(
  ["IMPLEMENTATION_PLAN.md"]="docs/plans"
  ["README_RATE_LIMITING_POC.md"]="docs/poc"
  ["TODO.md"]="docs/backlog"
)

# For each file in map:
#   - If exists in root
#   - If not already in target
#   - Move to target directory

# Exit 0 if nothing to do
```

**Validation**: Script is executable, no syntax errors

### Phase 3: Create Check Script (15 min)
**Goal**: Create validation script for CI

**File**: `scripts/check_markdown_layout.sh`

**Logic**:
```bash
#!/usr/bin/env bash
set -euo pipefail

# Find all *.md in root (not recursive)
# Exclude whitelist items
# If any found → report and exit 1
# Else → exit 0
```

**Validation**: Script is executable, reports violations correctly

### Phase 4: Test Scripts (Dry Run) (10 min)
**Goal**: Verify scripts work without making changes

```bash
# Test tidy script logic
# Test check script (should currently fail)
```

**Expected**: Scripts execute without errors, check script finds violations

### Phase 5: Execute Migration (5 min)
**Goal**: Move files to correct locations

```bash
./scripts/tidy_markdown.sh
```

**Expected**: Files moved, root clean

### Phase 6: Validate Results (5 min)
**Goal**: Confirm migration success

```bash
# Run check script (should now pass)
./scripts/check_markdown_layout.sh

# Verify file contents unchanged
diff IMPLEMENTATION_PLAN.md docs/plans/IMPLEMENTATION_PLAN.md || echo "Files moved correctly"

# List root markdown
ls -1 *.md
```

**Expected**: Check passes, only whitelisted files in root

### Phase 7: Documentation & Commit (10 min)
**Goal**: Document changes and commit

```bash
# Add all changes
git add .ai/ docs/ scripts/

# Commit with clear message
git commit -m "c-gateway: repo hygiene + .ai governance + markdown layout

- Add .ai/ governance structure (project, architecture, ADRs, etc.)
- Create repo hygiene task structure
- Add scripts/tidy_markdown.sh (idempotent migration)
- Add scripts/check_markdown_layout.sh (CI-ready validation)
- Move IMPLEMENTATION_PLAN.md → docs/plans/
- Move README_RATE_LIMITING_POC.md → docs/poc/
- Move TODO.md → docs/backlog/
"
```

**Expected**: Clean commit ready to push

## Total Estimated Time
~1 hour

## Rollback Plan
If issues arise:
```bash
git reset --hard HEAD  # If not yet committed
git revert <commit>    # If already committed
```

## Dependencies
- Git
- Bash
- Standard Unix tools (mkdir, mv, find)

## Risk Mitigation
- **Data Loss**: Use `mv` not `rm`, preserve all content
- **Git History**: Files tracked, not deleted
- **Idempotence**: Scripts check before acting
- **Validation**: Check script prevents regressions
