# Agent Prompts: Repo Documentation Hygiene

This file contains prompts and context for AI agents working on this task.

## Task Context Prompt

```
You are working on the C-Gateway repository hygiene task. The goal is to organize 
documentation by moving markdown files from the root directory to appropriate 
docs/ subdirectories, and creating automation scripts to maintain this organization.

Current state:
- Root contains: IMPLEMENTATION_PLAN.md, README_RATE_LIMITING_POC.md, TODO.md
- These should move to: docs/plans/, docs/poc/, docs/backlog/ respectively
- Only README.md and LICENSE.md should remain in root

Key requirements:
- Idempotent scripts (safe to run multiple times)
- Preserve file contents (no modifications)
- CI-friendly validation script
- Follow shell best practices
```

## Script Implementation Prompt

```
Create two bash scripts for repository hygiene:

1. scripts/tidy_markdown.sh:
   - Move non-whitelisted markdown files from root to appropriate docs/ subdirs
   - Whitelist: README.md, LICENSE.md, LICENCE.md
   - Mapping:
     * IMPLEMENTATION_PLAN.md → docs/plans/
     * README_RATE_LIMITING_POC.md → docs/poc/
     * TODO.md → docs/backlog/
   - Must be idempotent (check before moving)
   - Exit 0 if nothing to do
   - Create target directories if needed
   - Use 'set -euo pipefail' for safety

2. scripts/check_markdown_layout.sh:
   - Validate only whitelisted markdown files in root
   - Exit 0 if valid, non-zero if violations found
   - Print clear error messages for violations
   - Suitable for CI integration (no interactive prompts)
   
Both scripts should include usage help (-h flag).
```

## Validation Prompt

```
Validate the repo hygiene implementation:

1. Check directory structure:
   - Verify docs/plans/, docs/poc/, docs/backlog/ exist
   
2. Check file migration:
   - Confirm IMPLEMENTATION_PLAN.md in docs/plans/
   - Confirm README_RATE_LIMITING_POC.md in docs/poc/
   - Confirm TODO.md in docs/backlog/
   - Confirm originals removed from root
   
3. Check root cleanliness:
   - List all *.md in root
   - Should only see README.md and LICENSE.md (or LICENCE.md)
   
4. Test scripts:
   - Run check_markdown_layout.sh → expect exit 0
   - Run tidy_markdown.sh → expect "nothing to do"
   - Run tidy_markdown.sh again → test idempotence
   
5. Verify contents:
   - Diff migrated files to ensure unchanged
```

## Completion Criteria Prompt

```
This task is DONE when:

✅ All markdown files moved to correct docs/ subdirectories
✅ Only whitelisted files (README.md, LICENSE.md) remain in root
✅ scripts/tidy_markdown.sh is executable and idempotent
✅ scripts/check_markdown_layout.sh is executable and CI-ready
✅ Both scripts tested successfully
✅ Changes committed with clear message
✅ No file contents modified (only locations changed)

Verify with:
- ls -1 *.md  # Should show only README.md, LICENSE.md
- ./scripts/check_markdown_layout.sh && echo "PASS"
- git status  # Should be clean after commit
```
