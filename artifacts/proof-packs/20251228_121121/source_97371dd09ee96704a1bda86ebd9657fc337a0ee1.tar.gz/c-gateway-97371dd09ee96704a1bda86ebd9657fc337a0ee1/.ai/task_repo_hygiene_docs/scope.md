# Scope: Repo Documentation Hygiene

## In Scope

### 1. Documentation Migration
- Move `IMPLEMENTATION_PLAN.md` → `docs/plans/IMPLEMENTATION_PLAN.md`
- Move `README_RATE_LIMITING_POC.md` → `docs/poc/README_RATE_LIMITING_POC.md`
- Move `TODO.md` → `docs/backlog/TODO.md`
- Preserve git history (use `git mv` or ensure files are tracked)

### 2. Automation Scripts
- **`scripts/tidy_markdown.sh`**: Idempotent script to move misplaced markdown files
  - Check for markdown files in root (excluding whitelist)
  - Move to appropriate `docs/` subdirectories
  - Safe to run multiple times (idempotent)
  - Exit 0 if nothing to do

- **`scripts/check_markdown_layout.sh`**: Validation script
  - Verify only whitelisted markdown files remain in root
  - Exit non-zero if violations found
  - Suitable for CI integration

### 3. Directory Structure
Ensure these directories exist:
- `docs/plans/` - Implementation plans and design documents
- `docs/poc/` - Proof of concept documentation
- `docs/backlog/` - TODO lists and future work tracking

### 4. Whitelist
Root-level markdown files that are **allowed**:
- `README.md`
- `LICENSE.md` (or `LICENCE.md`)
- (Optionally: `CONTRIBUTING.md`, `SECURITY.md` if added later)

## Out of Scope

### Not Included
- Code reorganization (only documentation)
- Modification of existing documentation content
- Migration of non-markdown files
- Changing existing `docs/` structure (only additions)
- Git history rewriting
- CI pipeline integration (separate task)

### Future Work
- CI job to enforce layout checks (post-merge phase)
- Documentation index/catalog generation
- Automated link validation
- Documentation versioning strategy
