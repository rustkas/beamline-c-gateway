# Task: Repository Documentation Hygiene

## Objective
Organize repository documentation structure to maintain a clean root directory and improve documentation discoverability.

## Why This Task Matters
- **Discoverability**: Structured documentation is easier to find and navigate
- **Professionalism**: Clean root directory makes a better first impression
- **Maintainability**: Clear organization reduces confusion and technical debt
- **Consistency**: Aligns with mono-repo best practices
- **Automation**: Prevents future drift through automated checks

## Background
C-Gateway currently has several markdown files in the root directory that should be organized into the `docs/` hierarchy:
- `IMPLEMENTATION_PLAN.md` → `docs/plans/`
- `README_RATE_LIMITING_POC.md` → `docs/poc/`
- `TODO.md` → `docs/backlog/`

Root directory should contain only:
- `README.md` (project overview)
- `LICENSE.md` (or LICENCE.md)

## Related Documentation
- ADR-004: Repository Hygiene Standards (`.ai/decisions.md`)
