# Acceptance Criteria: Repo Documentation Hygiene

## Must Have (Required for Task Completion)

### AC-1: Documentation Files Migrated
- [ ] `IMPLEMENTATION_PLAN.md` exists at `docs/plans/IMPLEMENTATION_PLAN.md`
- [ ] `README_RATE_LIMITING_POC.md` exists at `docs/poc/README_RATE_LIMITING_POC.md`
- [ ] `TODO.md` exists at `docs/backlog/TODO.md`
- [ ] Original files removed from root directory
- [ ] File contents unchanged (no modifications during migration)

### AC-2: Root Directory Clean
- [ ] Only whitelisted markdown files remain in root:
  - `README.md` ✓
  - `LICENSE.md` or `LICENCE.md` ✓
- [ ] No other `*.md` files present in root

### AC-3: Tidy Script Functional
- [ ] `scripts/tidy_markdown.sh` exists and is executable
- [ ] Script successfully moves non-whitelisted markdown from root to appropriate `docs/` subdirs
- [ ] Script is idempotent (safe to run multiple times)
- [ ] Script exits 0 when no work needed
- [ ] Script preserves file contents during move

### AC-4: Check Script Functional
- [ ] `scripts/check_markdown_layout.sh` exists and is executable
- [ ] Script exits 0 when layout is correct (only whitelisted files in root)
- [ ] Script exits non-zero when violations found
- [ ] Script outputs clear error messages for violations
- [ ] Script suitable for CI integration (no manual input required)

### AC-5: Directory Structure
- [ ] `docs/plans/` directory exists
- [ ] `docs/poc/` directory exists
- [ ] `docs/backlog/` directory exists

## Should Have (Highly Desirable)

- [ ] Scripts include usage help (`-h` or `--help` flag)
- [ ] Scripts follow shell best practices (set -euo pipefail)
- [ ] Clear comments in scripts explaining logic
- [ ] Scripts output informative messages during execution

## Could Have (Nice to Have)

- [ ] Git history preserved for moved files
- [ ] README.md updated with new documentation locations
- [ ] Index of documentation in `docs/README.md`

## Validation Method

### Manual Testing
```bash
# 1. Run tidy script
./scripts/tidy_markdown.sh

# 2. Verify files moved
ls -la docs/plans/IMPLEMENTATION_PLAN.md
ls -la docs/poc/README_RATE_LIMITING_POC.md
ls -la docs/backlog/TODO.md

# 3. Verify root clean
ls -1 *.md  # Should only show README.md, LICENSE.md

# 4. Run check script
./scripts/check_markdown_layout.sh
echo $?  # Should be 0

# 5. Test idempotence
./scripts/tidy_markdown.sh
./scripts/tidy_markdown.sh
# Both runs should succeed without errors
```

### Definition of Done
- All "Must Have" criteria checked
- Manual validation completed successfully
- Changes committed to git with clear commit message
- No regressions in existing functionality
