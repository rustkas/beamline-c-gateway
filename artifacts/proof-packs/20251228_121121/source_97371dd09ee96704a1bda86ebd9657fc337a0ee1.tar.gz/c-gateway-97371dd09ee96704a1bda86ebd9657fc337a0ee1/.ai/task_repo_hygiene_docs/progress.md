# Progress: Repo Documentation Hygiene

**Status**: 🟢 IN PROGRESS  
**Started**: 2025-12-22  
**Target Completion**: 2025-12-22  

---

## Checklist

### Phase 1: Prepare Directories ✅
- [x] Create `docs/plans/`
- [x] Create `docs/poc/`
- [x] Create `docs/backlog/`

### Phase 2: Tidy Script ⏳
- [ ] Create `scripts/tidy_markdown.sh`
- [ ] Add whitelist logic
- [ ] Add file mapping
- [ ] Add move logic
- [ ] Make executable
- [ ] Test locally (dry run)

### Phase 3: Check Script ⏳
- [ ] Create `scripts/check_markdown_layout.sh`
- [ ] Add whitelist check
- [ ] Add violation reporting
- [ ] Make executable
- [ ] Test locally

### Phase 4: Migration ⏹️
- [ ] Run `tidy_markdown.sh`
- [ ] Verify files moved
- [ ] Verify contents unchanged

### Phase 5: Validation ⏹️
- [ ] Run `check_markdown_layout.sh` (expect success)
- [ ] Manual verification (ls *.md)
- [ ] Test idempotence (run tidy twice)

### Phase 6: Documentation & Commit ⏹️
- [ ] Commit changes
- [ ] Update task status to DONE

---

## Work Log

### 2025-12-22 18:15
- ✅ Created `.ai/` governance structure
  - `project.md`, `architecture.md`, `decisions.md`
  - `glossary.md`, `current_state.md`, `roadmap.md`
- ✅ Created task structure in `.ai/task_repo_hygiene_docs/`
  - `task.md`, `scope.md`, `acceptance.md`, `plan.md`
- ⏳ Next: Create automation scripts

---

## Blockers
None currently.

## Notes
- Initial structure creation completed
- Ready to implement automation scripts
- All documentation files already exist in root, ready for migration
