# Plan
1) Log fields
2) request_id/trace_id
3) Lifecycle logs
4) Tests
