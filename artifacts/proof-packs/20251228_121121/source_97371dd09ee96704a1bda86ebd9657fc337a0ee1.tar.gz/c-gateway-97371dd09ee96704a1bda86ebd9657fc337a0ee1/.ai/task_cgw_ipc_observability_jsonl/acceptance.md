# Acceptance Criteria
1) JSONL logs
2) request_id correlation
3) Unit tests

# Verification
См. plan.md для деталей
