# Goal (RU)
CP1-style JSONL observability для IPC

# Goal (EN)
CP1-style JSONL observability for IPC
