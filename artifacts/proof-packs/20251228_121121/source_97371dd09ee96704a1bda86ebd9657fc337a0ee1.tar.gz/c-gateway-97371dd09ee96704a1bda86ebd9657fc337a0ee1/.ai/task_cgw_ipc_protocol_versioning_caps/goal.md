# Goal (RU)
Версионирование протокола

# Goal (EN)
Protocol versioning
