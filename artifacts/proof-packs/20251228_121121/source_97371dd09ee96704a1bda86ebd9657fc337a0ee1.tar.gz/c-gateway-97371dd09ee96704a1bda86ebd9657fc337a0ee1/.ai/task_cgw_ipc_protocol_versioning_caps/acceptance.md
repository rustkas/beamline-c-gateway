# Acceptance Criteria
1) Capabilities message
2) Compatibility policy
3) Tests

# Verification
См. plan.md для деталей
