# C-Gateway Glossary

## Terms and Definitions

### C-Gateway
The C/C++ gateway service that provides the external interface to the Beamline system. Acts as a translation layer between external clients and the Beamline Router.

### Beamline Router
The core Erlang/OTP service that handles business logic, routing, and orchestration. Primary backend component that C-Gateway communicates with.

### CP1 (Contract Protocol v1)
Legacy contract format used for Router communication. Being phased out in favor of CP2.

### CP2 (Contract Protocol v2)
Current contract specification defining message structure, subjects, and validation rules for Router communication. Includes ownership mapping.

### NATS
High-performance message broker used for inter-service communication. Provides request-reply pattern.

### Subject
NATS concept: routing key for messages. In Beamline, subjects follow patterns like `router.action.entity` (e.g., `router.get.customer`).

### Request-Reply Pattern
Messaging pattern where a client sends a request and awaits a response. NATS provides native support with timeout handling.

### Rate Limiting
Mechanism to control the number of requests from a client within a time window. Prevents abuse and ensures fair resource allocation.

### Tenant
Logical isolation boundary for customers. Multi-tenant support allows multiple organizations to use the same infrastructure.

### Client ID
Unique identifier for an external client/application making requests to C-Gateway.

### Repo Hygiene
Practice of maintaining clean repository structure with proper organization of code, documentation, and configuration files.

### Whitelist
List of explicitly allowed items. In repo hygiene context: markdown files permitted in repository root.

### Idempotent
Operation that produces the same result regardless of how many times it's executed. Applied to `tidy_markdown.sh` script behavior.

## Acronyms

- **ADR**: Architecture Decision Record
- **API**: Application Programming Interface
- **CI**: Continuous Integration
- **CP**: Contract Protocol
- **gRPC**: Google Remote Procedure Call
- **HTTP**: Hypertext Transfer Protocol
- **OTP**: Open Telecom Platform (Erlang framework)
- **POC**: Proof of Concept
- **RBAC**: Role-Based Access Control
- **TBD**: To Be Determined
