# IPC Gateway v2.0 - Исправления и Статус

**Дата**: 2025-12-26T10:45:00+07:00  
**Статус**: Критичные проблемы P0 **ИСПРАВЛЕНЫ**

---

## ✅ Что исправлено (P0)

### P0.1: Socket Path унифицирован ✅

**Было**: Разные пути в разных компонентах  
**Сейчас**:
- Единый дефолт: `/tmp/beamline-gateway.sock`
- Переопределение: `export IPC_SOCKET_PATH=/path/to.sock`
- CLI опция: `-s /path/to.sock` в обоих бенчмарках
- Приоритет:CLI → ENV → DEFAULT

**Файлы**:
- `bench_ipc_throughput.c`: поддержка `-s`
- `bench_ipc_latency.c`: поддержка `-s`
- `run_benchmarks.sh`: проверяет `$IPC_SOCKET_PATH`

---

### P0.2: Используется РЕАЛЬНЫЙ IPC протокол ✅

**Было**: Свой формат `{magic, length, type, payload[256]}`  
**Сейчас**: **РЕАЛЬНЫЙ** `ipc_protocol.h/c`

**Изменения**:
```c
// Теперь используется:
#include "ipc_protocol.h"

// Создание сообщения:
ipc_message_t msg = {
    .type = IPC_MSG_PING,
    .payload = json_payload,
    .payload_len = strlen(json_payload)
};

// Кодирование:
ssize_t len = ipc_encode_message(&msg, frame_buf, sizeof(frame_buf));

// Декодирование response:
// 1. Читаем header (6 bytes)
// 2 Парсим length (network byte order)
// 3. Читаем payload
```

**Линковка**:
```cmake
target_link_libraries(bench-ipc-throughput PRIVATE ipc-protocol pthread)
target_link_libraries(bench-ipc-latency PRIVATE ipc-protocol pthread)
```

---

### P0.3: Корректный I/O с send_all/recv_all ✅

**Было**: `send()` / `recv()` без обработки partial I/O  
**Сейчас**: Полная реализация:

```c
static ssize_t send_all(int sock, const void *buf, size_t len) {
    const char *ptr = buf;
    size_t remaining = len;
    while (remaining > 0) {
        ssize_t sent = send(sock, ptr, remaining, MSG_NOSIGNAL);
        if (sent < 0) {
            if (errno == EINTR) continue;  // Retry on interrupt
            return -1;
        }
        ptr += sent;
        remaining -= sent;
    }
    return len;
}

// Аналогично recv_all()
```

**Дополнительно**:
- Таймауты: `SO_RCVTIMEO` / `SO_SNDTIMEO` (5-10 sec)
- Обработка `EINTR`
- `MSG_NOSIGNAL` для предотвращения `SIGPIPE`

---

## ✅ Что исправлено (P1)

### P1.1: run_benchmarks.sh проверяет сокет ✅

**Было**:
```bash
if ! pgrep -x "ipc-gateway" > /dev/null; then
    echo "IPC gateway not running"
fi
```

**Сейчас**:
```bash
if [ ! -S "$IPC_SOCKET_PATH" ]; then
    echo "ERROR: IPC socket not found at $IPC_SOCKET_PATH"
    echo "Please start IPC gateway first"
    exit 1
fi
```

---

### P1.2: Warmup phase добавлен ✅

**bench_ipc_latency.c**:
```c
#define WARMUP_REQUESTS 100

// Warmup phase
for (int i = 0; i < warmup; i++) {
    uint64_t dummy;
    measure_request(sock, &dummy);
}

// После warmup - реальные измерения
```

Можно отключить: `--no-warmup`

---

### P1.3: Поддержка разных payload sizes ✅

**bench_ipc_latency.c**:
```bash
# Тест с разными размерами:
./bench-ipc-latency -p 64    # 64 bytes
./bench-ipc-latency -p 256   # 256 bytes
./bench-ipc-latency -p 1024  # 1KB
./bench-ipc-latency -p 16384 # 16KB
```

**run_benchmarks.sh** автоматически тестирует:
- 64 bytes (minimal)
- 256 bytes (typical)
- 1024 bytes (realistic)

---

### P1.4: Timestamped results ✅

**Было**: `results/summary.md` (перезаписывался)  
**Сейчас**: `results/YYYYMMDD_HHMMSS/`

```
results/
├── 20251226_103045/
│   ├── throughput.txt
│   ├── latency_64b.txt
│   ├── latency_256b.txt
│   ├── latency_1024b.txt
│   └── summary.md
└── 20251226_104521/
    └── ...
```

---

## 📊 Новые возможности

### Улучшенный CLI

**Throughput**:
```bash
bench-ipc-throughput \
    -d 30              # Duration: 30 seconds
    -t 8               # Threads: 8
    -s /path/to.sock   # Socket path
```

**Latency**:
```bash
bench-ipc-latency \
    -n 20000           # Requests: 20,000
    -p 512             # Payload: 512 bytes
    -s /path/to.sock   # Socket path
    --no-warmup        # Skip warmup
```

---

## 🎯 Как использовать (ПРАВИЛЬНО)

### 1. Запустить IPC Gateway

```bash
cd build
./ipc-server-demo /tmp/beamline-gateway.sock &
```

Или с экспортом:
```bash
export IPC_SOCKET_PATH=/tmp/beamline-gateway.sock
./ipc-server-demo $IPC_SOCKET_PATH &
```

### 2. Проверить сокет

```bash
ls -l $IPC_SOCKET_PATH
# Должен быть: srwxr-xr-x (socket)
```

### 3. Запустить бенчмарки

```bash
cd benchmarks
./run_benchmarks.sh
```

### 4. Результаты

```bash
ls results/
# -> 20251226_104521/

cat results/20251226_104521/summary.md
```

---

## 📋 Что теперь измеряется ПРАВИЛЬНО

### Throughput

- **Реальный** IPC protocol (length-prefixed + JSON)
- **Реальный** socket path
- **Реальный** framing/encoding
- Multi-threaded load
- Атомарные счетчики

**Метрика**: requests/sec (завершенных запросов)

### Latency

- **Реальный** IPC protocol
- **Warmup** phase (100 requests)
- **Разные payload sizes** (64B, 256B, 1KB, 16KB)
- High-resolution timing (`CLOCK_MONOTONIC`)
- Percentiles: p50, p95, p99, p99.9
- Сортированные для точности

**Метрики**: min, mean, p50, p95, p99, p99.9, max (в milliseconds)

---

## ⚠️ Ограничения (что еще нужно)

### E2E с реальным Router

Текущие бенчмарки измеряют:
- ✅ IPC socket communication
- ✅ Protocol encoding/decoding
- ✅ Socket I/O performance

НЕ измеряют:
- ❌ Full NATS round-trip
- ❌ Router integration
- ❌ Real business logic
- ❌ JSON schema validation

**Требуется**: E2E test с реальным Router deployment

### Soak test с реальным gateway

Текущий soak test:
- ✅ Buffer pool (done, passed)
- ⏳ NATS pool (todo)
- ⏳ Full gateway под нагрузкой (todo)

**План**: Запустить gateway + benchmarks на несколько часов

---

## ✅ Checklist исправлений

- [x] P0.1: Socket path унифицирован
- [x] P0.2: Используется реальный IPC protocol  
- [x] P0.3: Корректный I/O (send_all/recv_all + timeouts)
- [x] P1.1: Проверка сокета вместо процесса
- [x] P1.2: Warmup phase
- [x] P1.3: Поддержка разных payload sizes
- [x] P1.4: Timestamped results
- [ ] P1.5: Soak test с реальным gateway (todo)
- [ ] P1.6: E2E с Router (требует Router setup)

---

## 🎯 Статус: "Готов для локальных измерений"

**Что можно делать СЕЙЧАС**:
- ✅ Измерить baseline v1.0/v2.0
- ✅ Сравнить производительность
- ✅ Найти узкие места
- ✅ Проверить влияние payload size

**Что требует дополнительной работы**:
- ⏳ E2E integration с Router
- ⏳ Long-running soak tests (hours)
- ⏳ Production-like load scenarios

**Вердикт**: Бенчмарки **исправлены и готовы** для локальной валидации.  
Для full production validation требуется Router integration.

---

**Обновлено**: 2025-12-26T10:45:00+07:00  
**Версия**: v2.0-benchmarks-fixed
