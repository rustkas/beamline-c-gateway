# Acceptance Criteria: C-Gateway IPC Gateway

## Must Have (Required for Task Completion)

### AC-1: IPC Server Functional
- [ ] Unix socket listener binds to `/tmp/beamline-gateway.sock`
- [ ] TCP fallback listener binds to `localhost:9999` (Windows/fallback)
- [ ] Accepts connections from multiple clients (up to configured limit)
- [ ] Non-blocking I/O (doesn't block on slow clients)
- [ ] Graceful shutdown (closes connections, deletes socket file)

### AC-2: IPC Protocol Implemented
- [ ] Binary framing with length-prefixed messages
- [ ] Message types: `TaskSubmit`, `TaskQuery`, `TaskCancel`, `StreamSubscribe`
- [ ] Protocol version negotiation (client/server version check)
- [ ] Error responses: `InvalidMessage`, `ProtocolMismatch`, `Timeout`

### AC-3: gRPC Client to Router
- [ ] gRPC client connects to Router IDE API
- [ ] Sends `TaskSubmit` requests
- [ ] Receives streaming responses
- [ ] Handles gRPC errors (deadline exceeded, unavailable, etc.)
- [ ] Automatic reconnection with exponential backoff

### AC-4: Streaming Works End-to-End
- [ ] IDE client sends `StreamSubscribe`
-

 [ ] Gateway forwards to Router via gRPC streaming call
- [ ] Router response chunks delivered to IDE in order
- [ ] Stream completes successfully (no data loss)
- [ ] Stream errors propagate to IDE (terminal error stops stream)
- [ ] No memory leaks (valgrind clean after 1000 streams)

### AC-5: HTTP Compat Mode (if enabled)
- [ ] `/api/v1/routes/decide` endpoint works (backward compatibility)
- [ ] `/v1/chat/completions` returns OpenAI-compatible streaming response
- [ ] SSE format correct (`data: {...}\n\n`, `data: [DONE]\n\n`)
- [ ] HTTP health endpoint `/health` returns 200 OK with status JSON

### AC-6: Configuration Works
- [ ] `GATEWAY_MODE=ide_ipc` enables only IPC server
- [ ] `GATEWAY_MODE=http_compat` enables only HTTP server
- [ ] `GATEWAY_MODE=both` enables both IPC and HTTP
- [ ] All environment variables apply correctly
- [ ] Invalid config logs error and exits gracefully

### AC-7: Observability
- [ ] JSON logs include: `request_id`, `trace_id`, `mode`, `transport`, `latency_us`
- [ ] Metrics endpoint `/metrics` returns Prometheus format
- [ ] Metrics include: connection_count, request_rate, grpc_latency_p95, error_rate
- [ ] Health endpoint shows Router connectivity status

### AC-8: Tests Pass
- [ ] Unit tests: `test_ipc_server`, `test_router_grpc_client`, `test_streaming` pass
- [ ] Integration test: end-to-end IDE → Gateway → Router (mock) passes
- [ ] Valgrind: no memory leaks, no invalid accesses
- [ ] Load test: 100 concurrent streams without crashes

## Should Have (Highly Desirable)

- [ ] Graceful degradation: IPC mode works even if gRPC fails (returns error to client)
- [ ] Metrics dashboard: Grafana dashboard for gateway metrics
- [ ] Performance baselines documented (p50/p95/p99 latency)
- [ ] Docker image with both modes available

## Could Have (Nice to Have)

- [ ] TLS support for gRPC (mutual TLS with Router)
- [ ] Configurable backpressure limits (max inflight requests)
- [ ] Admin API for runtime config changes (reload, drain connections)

## Validation Method

### Manual Testing (IPC Mode)

```bash
# 1. Start Router (mock or real)
# 2. Start Gateway in IPC mode
GATEWAY_MODE=ide_ipc \
ROUTER_GRPC_URL=localhost:50051 \
./build/c-gateway

# 3. Test Unix socket connection
echo '{"type":"TaskSubmit","payload":{"text":"test"}}' | \
  socat - UNIX-CONNECT:/tmp/beamline-gateway.sock

# 4. Verify streaming
# (Use test script that sends StreamSubscribe and reads chunks)
./tests/manual/test_ipc_streaming.sh

# 5. Check metrics
curl http://localhost:9090/metrics
```

### Manual Testing (HTTP Compat Mode)

```bash
# 1. Start Gateway in HTTP mode
GATEWAY_MODE=http_compat \
ROUTER_GRPC_URL=localhost:50051 \
HTTP_PORT=8080 \
./build/c-gateway

# 2. Test backward compat endpoint
curl -X POST http://localhost:8080/api/v1/routes/decide \
  -H 'Content-Type: application/json' \
  -d '{"from":"test@example.com", ...}'

# 3. Test OpenAI compat endpoint (streaming)
curl -X POST http://localhost:8080/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"gpt-4","messages":[{"role":"user","content":"hello"}],"stream":true}'

# Should return SSE stream:
# data: {"choices":[...],"delta":{"content":"Hello"}}\n\n
# ...
# data: [DONE]\n\n
```

### Automated Test Suite

```bash
# Build with gRPC support
cmake -S . -B build -DUSE_GRPC=ON
cmake --build build

# Run unit tests
./build/test_ipc_server
./build/test_router_grpc_client
./build/test_streaming

# Run integration tests
./build/test_ipc_gateway_integration

# Valgrind memory check
valgrind --leak-check=full --show-leak-kinds=all \
  ./build/test_streaming

# Load test (requires tmux/parallel)
./tests/load/run_load_test.sh \
  --connections 100 \
  --streams-per-conn 10 \
  --duration 60s
```

### Definition of Done

- [ ] All "Must Have" criteria checked
- [ ] Manual validation completed successfully
- [ ] Automated tests pass (unit + integration)
- [ ] Valgrind clean (no leaks)
- [ ] Load test passes (100 concurrent streams for 60s)
- [ ] Documentation complete (`docs/IDE_GATEWAY.md`)
- [ ] Example IDE plugin (NeoVim Lua) can connect and stream
- [ ] Changes committed with clear commit message
- [ ] No regressions in existing HTTP functionality
