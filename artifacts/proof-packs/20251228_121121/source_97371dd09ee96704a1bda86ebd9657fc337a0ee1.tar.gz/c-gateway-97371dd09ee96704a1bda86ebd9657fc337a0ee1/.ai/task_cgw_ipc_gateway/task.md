# Task: C-Gateway IPC Gateway / IDE Integration

## Objective

Transform C-Gateway from HTTP-only gateway to optional local IPC gateway supporting:
- Direct IDE integration (NeoVim, VSCode, Emacs)
- Low-latency Unix socket communication
- **NATS request-reply to Router** (unified transport, simpler architecture)
- Streaming responses (chat, indexing progress, long-running tasks)
- Optional HTTP compatibility mode for external tools

## Why This Task Matters

**Problem**: Current HTTP/NATS architecture is optimized for remote access, not local IDE communication
- HTTP adds unnecessary overhead for local tools
- Want **simple, unified architecture** (NATS everywhere)
- Need filesystem-based security (Unix sockets)
- Streaming responses not well-supported

**Solution**: Hybrid IPC gateway
- Unix sockets for local IDE ↔ Gateway (low latency)
- NATS for Gateway ↔ Router (unified transport)
- Reuse existing `nats_client_real.c` (no new code)
- Simpler build (no gRPC/protobuf dependencies)

**Impact**:
- Better developer experience (IDE integrations feel instant)
- **Simpler architecture** (NATS everywhere, not NATS + gRPC)
- **Easier maintenance** (one transport technology)
- Foundation for advanced IDE features (real-time diagnostics, incremental indexing)

## Background

Per **ADR-006 (revised)**, C-Gateway will support dual modes with **NATS-based transport**:

1. **`GATEWAY_MODE=ide_ipc`** (primary for local development):
   - Unix socket listener (Linux/macOS)
   - TCP localhost fallback (Windows)
   - **NATS request-reply to Router** (reuses existing client)
   - Streaming via JetStream or chunked messages

2. **`GATEWAY_MODE=http_compat`** (optional for external tools):
   - HTTP server on localhost
   - OpenAI-compatible endpoints
   - Same NATS backend
   - Backward compatibility with `/api/v1/routes/decide`

## Prerequisites

**NOT blocked by ADR-005**: ADR-005 only defers HTTP → NATS for perf isolation. IPC mode uses **local NATS** and can proceed independently.

Development prerequisites:
1. ✅ Mock Router with NATS (easier than gRPC)
2. ✅ Local NATS server (already used for testing)
3. ✅ Existing `nats_client_real.c` code
4. ⏳ JSON message schemas for IDE commands
5. ⏳ Unix socket security model

## Related Documentation

- **ADR-006**: C-Gateway as Local IPC Gateway (`.ai/decisions.md` - **revised for NATS**)
- **ADR-005**: Defer HTTP→NATS Integration (**not a blocker** for IPC mode)
- **Roadmap**: M6 - IDE Integration (`.ai/roadmap.md`)
