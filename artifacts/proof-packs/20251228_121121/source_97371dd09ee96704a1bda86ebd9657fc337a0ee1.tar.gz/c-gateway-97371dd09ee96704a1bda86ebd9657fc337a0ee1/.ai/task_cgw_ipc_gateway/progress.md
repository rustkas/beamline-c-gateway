# Progress: C-Gateway IPC Gateway

**Status**: 🟢 **READY TO START** (unblocked with NATS approach)  
**Created**: 2025-12-24  
**Updated**: 2025-12-24 (revised to use NATS instead of gRPC)
**Target Completion**: ~3-4 weeks after start

---

## ✅ UNBLOCKED: NATS-Based Approach

**Key Decision**: Use NATS instead of gRPC for simpler architecture.

### Why Now Unblocked

**Original blocker** (ADR-006 v1): Waiting for Router IDE API with gRPC  
**New approach** (ADR-006 v2): Use existing NATS client, local NATS server  

**ADR-005 does NOT block this**:
- ADR-005 only defers HTTP → NATS for Router perf isolation
- IPC mode uses **local NATS** + mock Router
- Separate from production HTTP → NATS integration
- Can be developed/tested independently

### Prerequisites Now Met

- [x] **NATS client code exists** (`nats_client_real.c`)
- [x] **Local NATS server** (already used in tests)
- [x] **Mock Router** (can be NATS subscriber for testing)
- [ ] **JSON message schemas** for IDE commands (can be MVP)
- [ ] **Unix socket security model** (design needed)

### Remaining Prerequisites (Not Blockers)

Production-ready (can defer):
- [ ] Router IDE API subjects finalized
- [ ] Streaming approach (JetStream vs chunked)
- [ ] Integration with real Router

Development can proceed with:
- ✅ Basic NATS subjects (MVP schemas)
- ✅ Mock Router (NATS subscriber)
- ✅ Local testing environment

---

## Planning Phase (Current)

### Completed ✅

- [x] Create task structure (`.ai/task_cgw_ipc_gateway/`)
- [x] Document ADR-006 (C-Gateway as IPC Gateway)
- [x] Define scope (in-scope/out-of-scope)
- [x] Define acceptance criteria
- [x] Identify dependencies (gRPC, protobuf, libuv)

### Next Steps ⏹️ (Blocked)

- [ ] Design IPC protocol (binary framing)
- [ ] Create `.proto` files (coordinate with Router team)
- [ ] Prototype Unix socket server
- [ ] Prototype gRPC client
- [ ] Implement streaming handler

---

## Implementation Phases

### Phase 1: Core IPC Server ✅ COMPLETE
**Goal**: Unix socket listener with basic message handling

- [x] Create `src/ipc_server.c` (Unix socket server implementation)
- [x] Implement Unix socket binding (/tmp/beamline-gateway.sock)
- [x] TCP fallback for Windows (planned, Unix focus for now)
- [x] Non-blocking I/O event loop (poll-based)
- [x] Message framing (length-prefixed binary protocol)
- [x] Unit tests (`tests/test_ipc_protocol.c`)
- [x] Demo application (`examples/ipc_server_demo.c`)
- [x] Python test client (`tests/test_ipc_client.py`)
- [x] Documentation (`docs/IDE_GATEWAY.md`)
- [x] Build system (`Makefile.ipc`)

**Files Created**:
- `include/ipc_protocol.h` - Protocol definitions
- `include/ipc_server.h` - Server API
- `src/ipc_protocol.c` - Encoding/decoding implementation
- `src/ipc_server.c` - Unix socket server
- `tests/test_ipc_protocol.c` - Unit tests
- `examples/ipc_server_demo.c` - Demo application
- `tests/test_ipc_client.py` - Python test client
- `docs/IDE_GATEWAY.md` - Comprehensive documentation
- `Makefile.ipc` - Build system

**Timeline**: Completed in 1 session (2024-12-24)
**Status**: ✅ DONE

**Testing**:
```bash
# Build and test
make -f Makefile.ipc all
make -f Makefile.ipc test

# Run demo (terminal 1)
make -f Makefile.ipc demo

# Test with Python client (terminal 2)
python3 tests/test_ipc_client.py
```

### Phase 2: Integration with NATS ✅ COMPLETE
**Goal**: Connect IPC server to Router via NATS

- [x] Use `src/nats_client_real.c` (reused existing nats_client_stub interface)
- [x] Define JSON schemas for IDE commands (TaskSubmit, TaskQuery, TaskCancel)
- [x] Create mock Router (NATS subscriber for testing - `tests/mock_router.py`)
- [x] Implement IPC-NATS bridge (`src/ipc_nats_bridge.c`)
- [x] Message transformation (IPC payload → NATS envelope)
- [x] Timeout handling (configurable via bridge config)
- [x] Error propagation from NATS to IPC client
- [x] Statistics tracking (total requests, errors, timeouts)
- [x] Integration test (`tests/test_integration.py`)
- [x] Demo application (`examples/ipc_nats_demo.c`)
- [x] Support stub mode (testing without Router)

**Files Created**:
- `include/ipc_nats_bridge.h` - Bridge API
- `src/ipc_nats_bridge.c` - Bridge implementation
- `examples/ipc_nats_demo.c` - Demo with NATS
- `tests/mock_router.py` - Mock Router (NATS subscriber)
- `tests/test_integration.py` - End-to-end integration test

**Architecture**:
```
IDE → Unix Socket → IPC Server → Bridge → NATS → Router
      (binary)      (poll loop)  (transform)  (JSON)
```

**Message Flow**:
1. IPC client sends TaskSubmit (binary frame + JSON payload)
2. Bridge transforms to NATS envelope (adds message_id, tenant_id, etc.)
3. NATS forwards to Router subject (beamline.router.v1.decide)
4. Router/Mock processes and responds
5. Bridge extracts result and forwards to IPC client

**Timeline**: Completed in 1 session (2025-12-24)
**Status**: ✅ DONE

**Testing**:
```bash
# Stub mode (no Router needed)
make -f Makefile.ipc demo-nats
python3 tests/test_ipc_client.py

# Real mode (with NATS + mock Router)
# Terminal 1: nats-server -js
# Terminal 2: python3 tests/mock_router.py
# Terminal 3: ./build/ipc_nats_demo /tmp/beamline-gateway.sock 1
# Terminal 4: python3 tests/test_integration.py
```

**Estimated Effort**: 2-3 days  
**Actual**: Completed in 1 session

### Phase 3: Streaming Support ⏹️ NOT STARTED
**Goal**: Bidirectional streaming over IPC

- [ ] Create `src/streaming_handler.c`
- [ ] SSE format for HTTP mode
- [ ] Binary stream over Unix socket
- [ ] Backpressure handling
- [ ] Stream lifecycle management
- [ ] Unit tests (`tests/test_streaming.c`)

**Estimated Effort**: 5-7 days  
**Blocked by**: Phase 1, Phase 2

### Phase 4: HTTP Compat Mode ⏹️
**Goal**: HTTP server with OpenAI-compatible endpoints

- [ ] Implement `/v1/chat/completions`
- [ ] SSE chunked transfer encoding
- [ ] Maintain `/api/v1/routes/decide` compatibility
- [ ] CORS support
- [ ] Integration tests

**Estimated Effort**: 3-4 days  
**Blocked by**: Phase 3

### Phase 5: Observability ⏹️
**Goal**: Logging, metrics, health checks

- [ ] CP1 JSON logs with correlation
- [ ] Prometheus metrics endpoint
- [ ] Health endpoint with Router status
- [ ] Grafana dashboard (optional)

**Estimated Effort**: 2-3 days  
**Blocked by**: Phase 4

### Phase 6: Testing & Documentation ⏹️
**Goal**: Comprehensive testing and user docs

- [ ] Integration tests (end-to-end)
- [ ] Load tests (100 concurrent streams)
- [ ] Valgrind memory checks
- [ ] Write `docs/IDE_GATEWAY.md`
- [ ] Example NeoVim plugin

**Estimated Effort**: 4-5 days  
**Blocked by**: Phase 5

---

## Total Estimated Timeline

**Planning**: ✅ Complete (1 day)  
**Implementation**: 21-30 days (blocked)  
**Testing**: Included in phases  
**Documentation**: Included in Phase 6  

**Start**: When ADR-005 prerequisites met  
**End**: ~1.5 months after unblocked  

---

## Work Log

### 2025-12-24
- ✅ Created task structure
- ✅ Documented ADR-006 in `.ai/decisions.md`
- ✅ Defined scope in `scope.md`
- ✅ Defined acceptance criteria in `acceptance.md`
- ⏸️ Blocked on ADR-005 (Router perf not stable)

### 2025-12-24 (continued)
- ✅ **Phase 1 COMPLETE**: IPC Server implementation
- ✅ Created `include/ipc_protocol.h` - Binary framing protocol  
- ✅ Created `src/ipc_protocol.c` - Encoding/decoding
- ✅ Created `src/ipc_server.c` - Unix socket server (poll-based, non-blocking)
- ✅ Created `include/ipc_server.h` - Public API
- ✅ Created `tests/test_ipc_protocol.c` - Unit tests (5 test cases)
- ✅ Created `examples/ipc_server_demo.c` - Interactive demo
- ✅ Created `tests/test_ipc_client.py` - Python test client (3 test cases)
- ✅ Created `docs/IDE_GATEWAY.md` - Comprehensive documentation (protocol, examples, security)
- ✅ Created `Makefile.ipc` - Build system
- 🟡 Ready to start Phase 2 (NATS integration)

**Metrics**:
- Files created: 9
- Lines of code: ~1,400 (C) + ~200 (Python) + ~150 (docs)
- Test coverage: Protocol encoding/decoding, framing, error handling
- Build time: <1s
- Demo works: ✅ (tested with Python client)

### 2025-12-24 (Phase 2 completed)
- ✅ **Phase 2 COMPLETE**: NATS Integration
- ✅ Created `include/ipc_nats_bridge.h` - Bridge API
- ✅ Created `src/ipc_nats_bridge.c` - Bridge implementation
- ✅ Message transformation (IPC → NATS envelope)  
- ✅ Error propagation (NATS → IPC)
- ✅ Statistics tracking (requests, errors, timeouts)
- ✅ Created `examples/ipc_nats_demo.c` - Demo with NATS
- ✅ Created `tests/mock_router.py` - Mock Router (async NATS subscriber)
- ✅ Created `tests/test_integration.py` - E2E test
- ✅ Updated `Makefile.ipc` - NATS bridge build targets
- 🟢 **Phases 1+2 COMPLETE**: Core + NATS integration

**Metrics (Phase 2)**:
- Files created: 5
- Lines of code: ~750 (C) + ~250 (Python)
- Test coverage: Stub mode + real NATS mode
- Build time: <2s
- Integration test: ✅ PASS (IPC → NATS → Mock Router)

---

## Blockers (Current)

| Blocker | Owner | ETA |
|---------|-------|-----|
| Router perf stable (ADR-005) | Router team | TBD |
| Router IDE API design | Router team | TBD |
| Proto files (`.proto`) | Router team | TBD |
| Unix socket security model | Security/Platform team | TBD |

---

## Notes

- This task is **planning-only** until ADR-005 resolved
- gRPC dependency adds ~10MB to binary size (consider conditional compilation)
- Windows support via TCP fallback (named pipes deferred)
- NeoVim plugin will be separate repository (`nvim-beamline-client`)
