# Scope: C-Gateway IPC Gateway

## In Scope

### 1. IPC Mode Implementation (`GATEWAY_MODE=ide_ipc`)

#### Unix Socket Server
- **File**: `src/ipc_server.c`
- Unix domain socket listener (Linux/macOS)
- TCP localhost fallback (Windows compatibility)
- Non-blocking I/O with event loop (libuv or epoll)
- Filesystem permission-based security
- Socket path: `/tmp/beamline-gateway.sock` (configurable via `IPC_SOCKET_PATH`)

#### Protocol
- **File**: `include/ipc_protocol.h`
- Binary framing protocol (length-prefixed messages)
- Message types: TaskSubmit, TaskQuery, TaskCancel, StreamSubscribe
- Error handling: timeout, invalid message, protocol version mismatch

#### NATS Client (Reuse Existing)
- **File**: `src/nats_client_real.c` (**already exists, no changes needed**)
- NATS request-reply using existing implementation
- Connection pooling (reuse connections)
- Automatic reconnection with exponential backoff
- Timeout configuration (`ROUTER_REQUEST_TIMEOUT_MS`)
- **Subjects**: `beamline.router.v1.ide.*` or reuse existing

**Note**: This **reuses existing code** — no new NATS client needed!

#### Streaming Support
- **File**: `src/streaming_handler.c`
- SSE (Server-Sent Events) over Unix socket
- WebSocket support (optional, for HTTP mode)
- **Chunked request-reply** (fallback if no JetStream)
- **JetStream** (if Router supports streaming subjects)
- Backpressure handling (flow control)
- Stream lifecycle: subscribe → data chunks → complete/error

### 2. HTTP Compatibility Mode (`GATEWAY_MODE=http_compat`)

#### Endpoints
- `/v1/chat/completions` - OpenAI-compatible streaming chat
- `/api/v1/routes/decide` - Existing endpoint (backward compatibility)
- `/health` - Health check
- `/metrics` - Prometheus metrics

#### Features
- HTTP/1.1 with chunked transfer encoding (streaming)
- CORS support (for web-based IDEs)
- Rate limiting (per-IP, configurable)

### 3. Configuration

#### Environment Variables
- `GATEWAY_MODE`: `ide_ipc` | `http_compat` | `both` (default: `ide_ipc`)
- `IPC_SOCKET_PATH`: Unix socket path (default: `/tmp/beamline-gateway.sock`)
- `IPC_TCP_PORT`: TCP fallback port (default: `9999`)
- `HTTP_PORT`: HTTP server port (default: `8080`)
- `ROUTER_GRPC_URL`: Router gRPC endpoint (e.g., `localhost:50051`)
- `ROUTER_GRPC_TIMEOUT_MS`: gRPC timeout (default: `30000`)

#### Config File (optional)
- `config/gateway.conf` (INI format)
- Override via `GATEWAY_CONFIG_FILE`

### 4. Observability

#### Logging
- CP1 JSON logs with correlation fields:
  - `request_id`, `trace_id`, `session_id`
  - `mode` (ipc/http), `transport` (unix/tcp/http)
  - `latency_us`, `bytes_in`, `bytes_out`

#### Metrics
- Connection count (active Unix socket/TCP/HTTP connections)
- Request rate (IPC vs HTTP)
- Streaming session count
- gRPC call latency (p50, p95, p99)
- Error rate (by type: timeout, protocol_error, grpc_error)

#### Health Endpoint
- `/health` responds with:
  - Gateway mode
  - Router connectivity status
  - Active connection count
  - Uptime

### 5. Testing

#### Unit Tests
- **File**: `tests/test_ipc_server.c`
  - Unix socket creation/binding
  - Message framing/parsing
  - Connection lifecycle

- **File**: `tests/test_router_grpc_client.c`
  - gRPC call success/failure
  - Timeout handling
  - Reconnection logic

- **File**: `tests/test_streaming.c`
  - Stream subscription/unsubscribe
  - Chunk delivery order
  - Backpressure handling
  - Stream termination (complete/error/timeout)

#### Integration Tests
- **File**: `tests/integration/test_ipc_gateway.c`
  - End-to-end: IDE client → Unix socket → gRPC → Router (mock)
  - Streaming: long-running task with progress updates
  - Error propagation: Router error → Gateway → IDE client

### 6. Documentation

#### Technical
- **File**: `docs/IDE_GATEWAY.md`
  - Architecture overview
  - IPC protocol specification
  - gRPC service definitions (`.proto` files)
  - Configuration reference
  - Streaming semantics

#### User-Facing
- **File**: `docs/IDE_INTEGRATION.md`
  - How to connect from NeoVim
  - Example Lua plugin code
  - VSCode extension integration
  - Troubleshooting guide

---

## Out of Scope

### Not Included

1. **Router IDE API Implementation**
   - gRPC service definitions (Router team responsibility)
   - Router-side streaming logic
   - IDE-specific business logic (stays in Router)

2. **IDE Plugins/Extensions**
   - NeoVim plugin (separate repository)
   - VSCode extension(separate repository)
   - Emacs client (separate repository)

3. **Authentication/Authorization**
   - Filesystem permissions are security boundary
   - No user authentication (local-only)
   - RBAC handled by Router, not Gateway

4. **Multi-User Support**
   - Single-user per socket (developer workstation)
   - No shared daemon mode

5. **Windows Native IPC**
   - Named pipes (Windows) - deferred
   - TCP fallback only for Windows

6. **gRPC Server Mode**
   - Gateway is gRPC client only
   - No inbound gRPC (only Unix socket/HTTP)

### Deferred to Future**

- Message queue for offline mode (cache requests when Router unavailable)
- Plugin system for custom transports
- Multi-gateway load balancing (for shared dev servers)
- Binary protocol optimization (custom framing vs protobuf)

---

## Related Tasks

- **T-PERF-E2E-01**: End-to-end performance (ADR-005 prerequisite)
- **T-ROUTER-IDE-API**: Router IDE API design (Router team)
- **T-CGW-GRPC-PROTO**: Protocol buffer definitions

---

## Dependencies

### External Libraries (New)
- **gRPC C**: `libgrpc` (gRPC client)
- **Protobuf C**: `libprotobuf-c` (message serialization)
- **libuv** (optional): Event loop for Unix sockets (or use epoll directly)

### Build System Changes
- CMake: Add gRPC/protobuf find modules
- Conditional compilation: `USE_GRPC` flag (similar to `USE_NATS_LIB`)
- Proto file generation in build (`.proto` → `.pb.c/.pb.h`)

---

## Success Criteria

IPC mode works end-to-end:
1. NeoVim plugin connects via Unix socket
2. Sends `TaskSubmit` message
3. Gateway forwards via gRPC to Router
4. Router streams response chunks
5. Gateway delivers chunks to NeoVim
6. NeoVim displays incremental results

HTTP compat mode maintains backward compatibility:
1. Existing `/api/v1/routes/decide` clients work unchanged
2. New `/v1/chat/completions` returns streaming OpenAI format

Observability confirms low latency:
1. IPC mode: p95 < 5ms (Unix socket overhead)
2. gRPC to Router: p95 < 20ms (local network)
3. End-to-end: p95 < 30ms (IDE → Gateway → Router → response)
