# Plan
1) Canonical JSON
2) Builder/validator
3) Error mapping
4) Tests
