# Goal (RU)
Согласование с Router контрактами

# Goal (EN)
Align with Router contracts
