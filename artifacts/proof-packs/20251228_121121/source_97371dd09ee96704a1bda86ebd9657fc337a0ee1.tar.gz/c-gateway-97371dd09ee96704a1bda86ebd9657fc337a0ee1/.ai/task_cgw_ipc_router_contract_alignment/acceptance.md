# Acceptance Criteria
1) Strict contract
2) Unified errors
3) Tests

# Verification
См. plan.md для деталей
