# C-Gateway Architecture

## System Architecture

```
External Clients
    ↓
[C-Gateway]
    ↓ (NATS request-reply)
[NATS Broker]
    ↓
[Beamline Router]
```

## Core Components

### 1. Request Handler
- Accepts incoming HTTP/gRPC requests
- Performs initial validation
- Routes to appropriate processor

### 2. Contract Validator
- Validates requests against CP2 contract schemas
- Ensures compliance with Router expectations
- Rejects malformed requests early

### 3. NATS Client
- Manages NATS connections
- Implements request-reply pattern
- Handles timeouts and retries
- Connection pooling

### 4. Response Processor
- Processes responses from Router
- Transforms to client-expected format
- Error handling and translation

### 5. Rate Limiter
- Per-client rate limiting
- Token bucket algorithm
- Configurable limits

## Data Flow

1. **Request Ingress**
   - Client → HTTP/gRPC endpoint
   - Parse and validate format
   - Extract metadata (client_id, tenant_id, etc.)

2. **Contract Validation**
   - Validate against CP2 schema
   - Check required fields
   - Verify data types

3. **NATS Publishing**
   - Construct NATS message with subject from CP2
   - Set timeout and headers
   - Publish and await response

4. **Response Handling**
   - Receive NATS response
   - Parse Router response format
   - Transform to client format
   - Return to client

## Configuration

Configuration sources in order of precedence:
1. Environment variables
2. Configuration file (`config/*.conf`)
3. Default values

## Deployment Model

- **Container**: Docker-based deployment
- **Scaling**: Horizontal scaling supported
- **State**: Stateless (except connection pools)
