# P0 Actions - Progress Tracking

**Date**: 2025-12-26T20:55:00+07:00

---

## P0-1: Benchmark Cleanup ✅ IN PROGRESS

### Completed:
- [x] Identified all benchmark files (5 files)
- [x] Found socket path inconsistency
  - `bench_*.c`: `/tmp/beamline-gateway.sock` ✅
  - `load_test.sh`: `/tmp/ipc-gateway.sock` ❌ → Fixed ✅
- [x] Created socket path contract document
- [x] Fixed `load_test.sh` to use canonical path

### Remaining:
- [ ] Review for old/duplicate benchmarks
- [ ] Archive if any found
- [ ] Update documentation

**Status**: 80% complete

---

## P0-2: Sanitizer Artifacts ⏳ RUNNING

### Completed:
- [x] Created artifact directories
- [x] Created collection script
- [x] Launched sanitizer collection

### Running:
- ⏳ Valgrind (4 components)
- ⏳ ASan (4 components)
- ⏳ UBSan (4 components)  
- ⏳ TSan (2 components)

### Pending:
- [ ] Wait for completion (~2 min)
- [ ] Review summary report
- [ ] Commit artifacts

**Status**: 50% complete (running)

---

## P0-3: Soak with Metrics ⏳ PENDING

### TODO:
- [ ] Create metrics collection script
- [ ] Run 30-min soak with RSS/FD monitoring
- [ ] Save CSV with periodic samples
- [ ] Generate summary

**Status**: 0% complete

---

## P0-4: Full E2E with Router ⏳ PENDING

### Blockers:
- Requires Router deployment
- Recommend doing in staging environment

**Status**: 0% complete (staging activity)

---

## Timeline

**Completed**: ~1 hour  
**Remaining**: ~2-3 hours (P0-2 + P0-3)  
**Total today**: ~3-4 hours

**P0-4**: Staging environment (separate timeline)
