# !!! DEPRECATED DOCUMENTS !!!

The following documents contain OUTDATED or CONTRADICTORY readiness assessments and are **NO LONGER VALID**.

---

## DO NOT USE

❌ **FINAL_STATUS.md** - Outdated  
❌ **FINAL_STATUS_COMPLETE.md** - Contradictory percentages (90-95%)  
❌ **FINAL_STATUS_CORRECTED.md** - Superseded  
❌ **Any document with single-number readiness without two-axis breakdown**

---

## USE ONLY

✅ **[docs/readiness/TWO_AXIS_CANONICAL.md](../docs/readiness/TWO_AXIS_CANONICAL.md)** - CANONICAL format

✅ **[docs/readiness/MANAGEMENT_DECISION.md](../docs/readiness/MANAGEMENT_DECISION.md)** - Decision document

---

## Why Deprecated

1. **Contradictory percentages**: Multiple documents claimed different readiness (60-70% vs 90-95%)
2. **Missing evidence**: Claims without artifact links
3. **No axis breakdown**: Single number hides where problems are
4. **Confusion**: Made deployment decisions unclear

---

## Two-Axis Format (ONLY Valid Format)

**Structure**:
```
- Axis 1: Core (Memory/Stability/Performance) → X%
- Axis 2: System (Integration/Semantics) → Y%  
- Overall: Weighted average
- Deployment Decision: Staging/Production + rationale
```

**Evidence Required**:
- Artifact links for all claims
- Reproducible commands
- Exact measurements

---

## Migration

All future readiness assessments MUST use two-axis format from `TWO_AXIS_CANONICAL.md`.

---

**Last Updated**: 2025-12-27  
**Status**: All pre-two-axis documents DEPRECATED
