# Task 26: Distributed Rate Limiting - Implementation Guide

**Status**: Deferred (optional - only needed for multi-instance deployment)

## Current State

IPC Gateway has:
- ✅ Local rate limiting (in-memory)
- ✅ Per-tenant rate limiting
- ✅ Token bucket algorithm

This is sufficient for single-instance deployments.

## When Distributed Rate Limiting is Needed

Redis-backed rate limiting is only required if:
- Multiple gateway instances run simultaneously
- Rate limits must be enforced across all instances
- Centralized rate limit state is needed

## Implementation Plan (If Needed)

### Dependencies
```bash
sudo apt-get install redis-server libhiredis-dev
```

### Code Already Exists!

Good news: We already have Redis rate limiter implementation:
- ✅ `include/redis_rate_limiter.h`
- ✅ `src/redis_rate_limiter.c`
- ✅ Tests: `tests/redis_rate_limiter_test.c`

### To Enable

**1. Build with Redis support**:
```bash
cd build
cmake .. -DUSE_REDIS=ON
make
```

**2. Configure Redis**:
```bash
export C_GATEWAY_REDIS_RATE_LIMIT_ENABLED=1
export C_GATEWAY_REDIS_RATE_LIMIT_URL=redis://localhost:6379
export C_GATEWAY_REDIS_RATE_LIMIT_REQUESTS_PER_SECOND=100
export C_GATEWAY_REDIS_RATE_LIMIT_BURST=200
```

**3. Start Redis**:
```bash
docker run -d -p 6379:6379 redis:latest
# OR
sudo systemctl start redis-server
```

**4. Run gateway**:
```bash
./build/ipc-gateway
```

## What's Implemented

The Redis rate limiter has:
- ✅ Connection pooling (32 connections)
- ✅ Lua script for atomic operations
- ✅ Token bucket implementation
- ✅ Per-tenant quotas
- ✅ Metrics integration
- ✅ Fallback to local if Redis unavailable
- ✅ Tests (unit + integration)

## Decision

**For v2.0**: ⏸️ **IMPLEMENTED BUT OPTIONAL**

Reasons:
1. Code already exists (from previous work)
2. Can be enabled with CMake flag
3. Requires external dependency (Redis)
4. Most deployments are single-instance

**Recommendation**: Enable only if:
- Multi-instance deployment confirmed
- Centralized rate limiting required
- Redis infrastructure available

## How to Test

```bash
# 1. Start Redis
docker run -d --name redis -p 6379:6379 redis:latest

# 2. Build with Redis
cd build
cmake .. -DUSE_REDIS=ON -DUSE_REDIS_FOR_TESTS=ON
make

# 3. Run tests
./c-gateway-redis-rate-limiter-test
./c-gateway-redis-rate-limiter-integration-test

# 4. Test with gateway
C_GATEWAY_REDIS_RATE_LIMIT_ENABLED=1 ./ipc-gateway
```

## Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Gateway 1  │────▶│             │◀────│  Gateway 2  │
└─────────────┘     │    Redis    │     └─────────────┘
                    │  (Shared    │
┌─────────────┐     │   State)    │     ┌─────────────┐
│  Gateway 3  │────▶│             │◀────│  Gateway 4  │
└─────────────┘     └─────────────┘     └─────────────┘
```

---

**Task Status**: Code exists, marked as optional ✅  
**Can activate**: Yes, immediately with CMake flag  
**Breaking changes**: No
