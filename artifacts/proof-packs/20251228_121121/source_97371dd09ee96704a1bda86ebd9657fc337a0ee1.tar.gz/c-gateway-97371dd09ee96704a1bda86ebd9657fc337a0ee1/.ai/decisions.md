# Architecture Decision Records (ADR)

## ADR-001: C/C++ as Primary Language

**Status**: Accepted

**Context**: Need high-performance gateway with minimal latency overhead.

**Decision**: Use C/C++ for core implementation.

**Rationale**:
- Low latency requirements
- Efficient memory management
- Direct control over networking and threading
- Good NATS client library support

**Consequences**:
- Requires careful memory management
- More complex development compared to higher-level languages
- Strong performance characteristics

---

## ADR-002: NATS Request-Reply Pattern

**Status**: Accepted

**Context**: Need reliable communication with Beamline Router.

**Decision**: Use NATS request-reply pattern for all Router communication.

**Rationale**:
- Simple request-response semantics
- Built-in timeout handling
- Message broker decouples services
- Supports future scaling

**Consequences**:
- NATS becomes critical dependency
- Network hop adds latency (acceptable trade-off)
- Requires NATS infrastructure

---

## ADR-003: CP2 Contract Enforcement

**Status**: Accepted

**Context**: Need standardized communication protocol with Router.

**Decision**: Enforce CP2 contracts at C-Gateway level before forwarding to Router.

**Rationale**:
- Early validation reduces Router load
- Clear contract ownership
- Simplified debugging
- Protects Router from malformed requests

**Consequences**:
- Contract changes require C-Gateway updates
- Validation logic must stay in sync with Router
- Additional processing overhead (minimal)

---

## ADR-004: Repository Hygiene Standards

**Status**: Accepted

**Context**: Need clean, maintainable repository structure.

**Decision**: 
- Root-level markdown limited to README.md and LICENSE.md
- All other documentation in `docs/` subdirectories
- Automated scripts for enforcement

**Rationale**:
- Reduces root clutter
- Improves discoverability
- Consistent with mono-repo best practices
- Automated enforcement prevents drift

**Consequences**:
- Existing files need migration
- CI checks required for enforcement
- Clear documentation hierarchy

---

## ADR-005: Defer C-Gateway NATS Integration Until Router Perf Stabilization

**Status**: Accepted  
**Date**: 2025-12-22  
**Updated**: 2025-12-24

**Context**: During P0 NATS integration diagnostic, Router performance regression investigation is ongoing. C-Gateway currently operates in stub mode with no live NATS connection.

**Decision**: DO NOT integrate c-gateway **HTTP → NATS → Router path** until Router performance baseline is stable and regression guards are established.

**Scope of Block**: This decision **only blocks**:
- Installing/linking libnats library
- Building c-gateway with `-DUSE_NATS_LIB=ON`
- Enabling real NATS client (`nats_client_real.c`)
- End-to-end testing of HTTP → NATS → Router flow

**Not Blocked**: Other development work can proceed in parallel:
- ✅ **IPC Gateway development** (uses gRPC, not NATS) → ADR-006
- ✅ **HTTP server improvements** (routing, validation, error handling)
- ✅ **Contract validation** (offline, no live Router needed)
- ✅ **Testing infrastructure** (unit tests, mock Router, CI/CD)
- ✅ **Documentation** (architecture, APIs, runbooks)
- ✅ **Observability** (logging, metrics, tracing)

**Rationale**:
- Router perf regression is reproducible in standalone mode (isolated)
- Adding c-gateway **via NATS** introduces additional network hop and runtime complexity
- Blurs source of performance degradation during investigation
- **Isolation principle**: Investigate regressions without external variables
- Contracts can be validated offline using `contract_check.py`
- Installing libnats and rebuilding c-gateway adds no value at this phase

**Current Approach**:
- C-Gateway remains in **stub mode** (`nats_client_stub.c` compiled by default)
- Contracts validated offline using `contracts/cp2_contracts.json`
- Router perf investigation proceeds in isolation (Router + local NATS only)
- No libnats installation required until prerequisites met
- **Other features** (IPC, gRPC, streaming) can be developed independently

**Prerequisites for NATS Integration**:

Create task `T-PERF-E2E-01: Gateway ↔ Router End-to-End Performance` when ALL met:
1. ✅ Router performance stable (p95/p99 within thresholds, 3+ consecutive green Heavy CT runs)
2. ✅ Performance baseline documented and accepted
3. ✅ Regression guards enabled in CI and passing reliably
4. ✅ Environment stability confirmed (CPU pinning, no contention)

**Consequences**:
- ✅ Clear isolation boundary for perf investigation
- ✅ Faster iteration (no multi-service orchestration overhead)
- ✅ Better diagnostic signal (metrics directly attributable to Router)
- ✅ Resource efficiency (don't build infrastructure we don't need yet)
- ✅ **Parallel development tracks** (IPC Gateway, HTTP improvements) can proceed
- ⚠️ Deferred end-to-end NATS latency validation
- ⚠️ No live NATS contract roundtrip testing yet

**Related Documentation**:
- `docs/P0_NATS_INTEGRATION_DIAGNOSTIC.md` - Technical analysis
- `docs/P0_SUMMARY.md` - Executive summary
- ADR-003: CP2 Contract Enforcement
- ADR-006: IPC Gateway (uses gRPC, **not blocked** by this decision)

---

## ADR-006: C-Gateway as Local IPC Gateway / Compatibility Layer

**Status**: Proposed  
**Date**: 2025-12-24  
**Updated**: 2025-12-24 (revised transport decision)

**Context**: C-Gateway evolution beyond HTTP gateway to support IDE integration and local development workflows.

**Problem**: 
- IDEs (NeoVim, VSCode extensions) need low-latency local communication with Router
- External CLI tools need OpenAI-compatible HTTP endpoints
- Streaming responses (chat, indexing progress) not well-supported
- Want **simple, unified architecture** (avoid multiple transport technologies)

**Decision**: Transform C-Gateway into optional local IPC gateway with dual modes:

1. **`GATEWAY_MODE=ide_ipc`** (primary):
   - **Unix domain sockets** (Linux/macOS) + TCP localhost fallback (Windows)
   - **NATS request-reply to Router** (unified transport, reuses existing code)
   - Streaming support via **NATS JetStream** or request-reply chunking
   - Local-only connections (security boundary)

2. **`GATEWAY_MODE=http_compat`** (optional):
   - HTTP server on localhost for external CLI/integrations
   - OpenAI-compatible `/v1/chat/completions` endpoint
   - Maintains backward compatibility with existing `/api/v1/routes/decide`
   - Same NATS backend

**Rationale**:

**Why IPC mode**:
- Unix sockets: 2-3x lower latency vs TCP localhost
- Direct IDE integration without HTTP stack
- Simpler security model (filesystem permissions)

**Why NATS (instead of gRPC)**:
- **Unified architecture**: NATS everywhere (no gRPC dependency)
- **Reuse existing code**: `nats_client_real.c` already implemented
- **Simpler build**: No protobuf codegen, no gRPC C library
- **Easier debugging**: Single protocol stack
- **Discovery/routing**: NATS subjects provide natural service discovery
- **Streaming**: JetStream or chunked request-reply

**Trade-off accepted**:
- Slightly higher serialization overhead (JSON vs protobuf) - **acceptable for local IPC**
- NATS doesn't support Unix sockets directly - **solved by hybrid approach**

**Why dual modes**:
- IDE tools benefit from IPC (NeoVim, Emacs, VSCode plugins)
- External tools expect HTTP (curl, Postman, REST clients)
- Not all environments support Unix sockets (Windows pre-WSL2)

**Architecture (Hybrid Approach)**:

```
┌─────────────┐
│  IDE/NeoVim │
└──────┬──────┘
       │ Unix Socket /tmp/beamline-gateway.sock
       │ (binary framing, low latency)
       │
┌──────▼────────────┐
│  IPC Server       │
│  (ipc_server.c)   │
│  - Unix socket    │
│  - Message frame  │
└──────┬────────────┘
       │ NATS request-reply
       │ (JSON, subjects: beamline.router.v1.*)
┌──────▼────────────┐
│  NATS Server      │
│  (localhost:4222) │
└──────┬────────────┘
       │ NATS pub/sub
┌──────▼────────────┐
│  Beamline Router  │
│  (Erlang)         │
└───────────────────┘

// HTTP mode (external tools)
External CLI → HTTP :8080 → http_server.c → NATS → Router
```

**Implementation Components**:
- `src/ipc_server.c` - Unix socket listener with binary framing
- `src/nats_client_real.c` - **Reuse existing** NATS client (no new code needed)
- `src/streaming_handler.c` - SSE/WebSocket for HTTP mode, chunking for IPC
- `include/ipc_protocol.h` - IPC message format (length-prefixed binary)
- `tests/test_ipc_gateway.c` - IPC functionality tests
- `tests/test_streaming.c` - Streaming behavior tests

**Consequences**:

**Positive**:
- ✅ **Simpler architecture** (NATS everywhere, no gRPC)
- ✅ **Reuse existing code** (nats_client_real.c already works)
- ✅ **Easier build** (no protobuf/gRPC dependencies)
- ✅ **Lower latency for IPC** (Unix sockets for IDE ↔ Gateway)
- ✅ **Unified monitoring** (all traffic via NATS, single observability stack)
- ✅ **Better developer experience** (local tools work seamlessly)
- ✅ **Optional deployment** (not required for server-only setups)

**Negative**:
- ⚠️ JSON serialization overhead (vs binary protobuf) - **acceptable for local IPC**
- ⚠️ Streaming via chunked messages (not native streams like gRPC) - **JetStream available**
- ⚠️ Platform-specific code (Unix sockets vs Windows named pipes)

**Alternatives Considered**:

1. **gRPC to Router** (original plan):
   - Rejected: Adds complexity (two transport technologies)
   - Requires new dependencies (libgrpc, protobuf)
   - More complex build system

2. **HTTP-only with WebSockets**:
   - Rejected: Higher latency for local IPC
   - No filesystem-based security boundary

3. **Separate binary for IPC vs HTTP**:
   - Rejected: Maintenance burden
   - Users need to choose which to deploy

**Prerequisites** (before production deployment):

1. ⏳ Router API subjects documented (`beamline.router.v1.ide.*` or reuse existing)
2. ⏳ Message format agreed (JSON schema for IDE commands)
3. ⏳ Unix socket security model defined (permissions, auth)
4. ⏳ Streaming approach decided (JetStream vs chunked request-reply)

**Development Prerequisites** (much lower bar):
- ✅ Mock Router with NATS (easier than gRPC mock)
- ✅ Basic message schemas (JSON, can be MVP)
- ✅ Local NATS server
- ✅ Existing `nats_client_real.c` code

**Note**: This work is **NOT blocked by ADR-005**, which only defers **HTTP → NATS integration** for performance isolation. IPC mode can be developed/tested independently with local NATS + mock Router.

**Related**:
- ADR-005: Defer **HTTP → NATS** Integration (IPC mode uses local NATS, **not affected**)
- ADR-002: NATS Request-Reply (extended for IDE mode)
- Task: `T-CGW-IPC-GATEWAY` (planning and implementation)

**Review Date**: After mock Router with IDE API subjects is available

---
