# Plan
1) Identifier
2) Message type
3) Mock Router
4) Tests
