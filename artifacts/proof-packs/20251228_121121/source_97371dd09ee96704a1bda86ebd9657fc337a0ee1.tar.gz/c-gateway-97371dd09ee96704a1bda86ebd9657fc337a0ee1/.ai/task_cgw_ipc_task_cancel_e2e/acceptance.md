# Acceptance Criteria
1) TaskCancel message
2) Idempotency
3) E2E test

# Verification
См. plan.md для деталей
