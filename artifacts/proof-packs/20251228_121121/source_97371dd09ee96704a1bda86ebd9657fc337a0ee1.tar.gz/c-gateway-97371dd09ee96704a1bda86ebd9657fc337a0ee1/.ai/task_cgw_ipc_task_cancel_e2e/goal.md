# Goal (RU)
End-to-end cancellation

# Goal (EN)
End-to-end cancellation
