# Acceptance Criteria
1) Единая конфигурация
2) Единая семантика
3) Одинаковые ошибки

# Verification
См. plan.md для деталей
