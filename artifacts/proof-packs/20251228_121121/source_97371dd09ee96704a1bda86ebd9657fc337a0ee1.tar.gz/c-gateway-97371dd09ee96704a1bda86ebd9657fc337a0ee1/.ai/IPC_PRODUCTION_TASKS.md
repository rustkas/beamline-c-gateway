# IPC Gateway Production Readiness - Task Registry

**Created**: 2025-12-24  
**Status**: Planning Phase  
**Total Tasks**: 15

---

## Task Categories

### 🔧 Infrastructure (Tasks 1-2)
- `task_cgw_ipc_build_integration` - Integrate IPC into main build
- `task_cgw_ipc_config_contract` - Unified env contract + validation

### 📊 Observability (Tasks 3-4)
- `task_cgw_ipc_observability_jsonl` - CP1-style JSONL logs
- `task_cgw_ipc_log_sanitization` - PII/secret filtering

### 🔒 Contracts & Reliability (Tasks 5-7)
- `task_cgw_ipc_router_contract_alignment` - Strict DecideRequest/Response
- `task_cgw_ipc_subjects_replyto_unification` - Unified NATS subjects
- `task_cgw_ipc_nats_resilience` - Reconnect, backoff, degradation

### ⚡ Performance & Safety (Tasks 8-10)
- `task_cgw_ipc_backpressure` - Inflight limits + BUSY rejection
- `task_cgw_ipc_peercred_authz` - SO_PEERCRED authorization
- `task_cgw_ipc_protocol_versioning_caps` - Version negotiation

### 🧪 Quality & Features (Tasks 11-13)
- `task_cgw_ipc_json_schema_validation` - Schema validation before NATS
- `task_cgw_ipc_task_cancel_e2e` - End-to-end cancellation
- `task_cgw_ipc_streaming_phase3` - Streaming responses (Phase 3)

### 🎯 Production Ready (Tasks 14-15)
- `task_cgw_ipc_fuzz_sanitizers_ci` - Fuzz + ASan/UBSan
- `task_cgw_ipc_ops_release_compliance` - Runbook + health + SBOM

---

## Quick Reference

| ID | Task Name | Priority | Estimated | Dependencies |
|----|-----------|----------|-----------|--------------|
| 1  | Build Integration | P0 | 2d | Phase 1+2 |
| 2  | Config Contract | P0 | 1d | - |
| 3  | Observability JSONL | P1 | 3d | Task 2 |
| 4  | Log Sanitization | P1 | 2d | Task 3 |
| 5  | Router Contract | P0 | 2d | - |
| 6  | Subjects Unification | P1 | 2d | Task 5 |
| 7  | NATS Resilience | P0 | 3d | - |
| 8  | Backpressure | P1 | 2d | - |
| 9  | PeerCred AuthZ | P2 | 2d | - |
| 10 | Protocol Versioning | P1 | 2d | - |
| 11 | Schema Validation | P1 | 3d | Task 5 |
| 12 | Task Cancel E2E | P2 | 2d | Task 5 |
| 13 | Streaming Phase3 | P1 | 5d | Phase 2 |
| 14 | Fuzz + Sanitizers | P1 | 3d | Task 1 |
| 15 | Ops/Release | P0 | 3d | All above |

**Total Estimated**: ~40 days

---

## Implementation Phases

### Phase A: Foundation (Tasks 1, 2, 5, 7)
**Goal**: Solid base for production
- Build integration
- Config contract
- Router contracts
- NATS resilience

**Deliverables**:
- Unified build
- Validated config
- Strict contracts
- Resilient NATS

### Phase B: Observability & Safety (Tasks 3, 4, 8)
**Goal**: Production-grade monitoring and safety
- JSONL logging
- PII sanitization
- Backpressure handling

**Deliverables**:
- Correlated logs
- No secrets in logs
- No memory explosions

### Phase C: Advanced Features (Tasks 6, 10, 11, 13)
**Goal**: Feature completeness
- Subjects unification
- Protocol versioning
- Schema validation
- Streaming

**Deliverables**:
- Unified path semantics
- Backward compat
- Early validation
- Streaming support

### Phase D: Quality & Operations (Tasks 9, 12, 14, 15)
**Goal**: Production readiness
- Authorization
- Cancellation
- Fuzzing
- Ops runbook

**Deliverables**:
- Secure local access
- Cancelable tasks
- No UB/overflows
- Operational docs

---

## File Structure

Each task has:
```
.ai/task_<name>/
├── goal.md                    # RU+EN objectives
├── acceptance.md              # Criteria + verification
├── plan.md                    # Implementation steps
├── progress.md                # Facts only (source of truth)
└── state_capture_prompt.md    # Prompt for state capture
```

---

## Status Tracking

**Completed**: 4/15 ✅  
**Progress**: ▓▓▓▓░░░░░░░░░░░ 27%

**Phase A Complete** (4/4): ✅
- ✅ Task 1: Build Integration
- ✅ Task 2: Config Contract
- ✅ Task 5: Router Contract  
- ✅ Task 7: NATS Resilience

**Next**: Phase B - Observability & Safety

---

## Notes

- All tasks assume Phases 1+2 are complete (IPC Server + NATS Integration)
- P0 = Must have for production
- P1 = Should have for production
- P2 = Nice to have / post-launch

**See also**:
- `.ai/task_cgw_ipc_gateway/` - Original IPC Gateway planning
- `.ai/decisions.md` - ADR-006 (IPC Gateway decision)
- `docs/IDE_GATEWAY.md` - IPC Gateway documentation
